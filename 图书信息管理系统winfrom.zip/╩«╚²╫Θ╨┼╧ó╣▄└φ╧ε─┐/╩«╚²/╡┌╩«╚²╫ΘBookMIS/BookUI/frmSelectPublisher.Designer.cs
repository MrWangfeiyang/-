﻿namespace BookUI
{
    partial class frmSelectPublisher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tvPublisherList = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // tvPublisherList
            // 
            this.tvPublisherList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvPublisherList.Location = new System.Drawing.Point(0, 0);
            this.tvPublisherList.Margin = new System.Windows.Forms.Padding(2);
            this.tvPublisherList.Name = "tvPublisherList";
            this.tvPublisherList.Size = new System.Drawing.Size(165, 267);
            this.tvPublisherList.TabIndex = 0;
            this.tvPublisherList.DoubleClick += new System.EventHandler(this.tvPublisherList_DoubleClick);
            // 
            // frmSelectPublisher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(165, 267);
            this.Controls.Add(this.tvPublisherList);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSelectPublisher";
            this.Text = "选择出版社";
            this.Load += new System.EventHandler(this.frmSelectPublisher_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvPublisherList;
    }
}