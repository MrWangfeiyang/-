﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmBibliothecaInfoManage : Form
    {
        public frmBibliothecaInfoManage()
        {
            InitializeComponent();
        }

        BookApp.bibliothecaClass objBibliotheca = new BookApp.bibliothecaClass();


        private void frmBibliothecaInfoManage_Load(object sender, EventArgs e)
        {
            this.Top = 0;
            this.Left = 0;
            this.Width = 900;
            this.Height = 620;
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Alignment =System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = headerStyle;
            dataGridView1.DataSource = objBibliotheca.getBibliothecaDataAll();
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            frmBibliothecaInfoAdd bibliothecaInfoAdd = new frmBibliothecaInfoAdd();
            bibliothecaInfoAdd.ShowDialog();
            dataGridView1.DataSource = objBibliotheca.getBibliothecaDataAll();

        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            string currentBookNo = null;
            currentBookNo = dataGridView1.Rows[dataGridView1.CurrentRow.Index]
                                                   .Cells[0].Value.ToString();
            frmBibliothecaInfoEdit bookInfoEdit =
                                   new frmBibliothecaInfoEdit(currentBookNo);
            bookInfoEdit.ShowDialog();
            dataGridView1.DataSource = objBibliotheca.getBibliothecaDataAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要删除此纪录吗?", "警告信息",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string strDelRow = null;
                strDelRow = dataGridView1.Rows[dataGridView1.CurrentRow.Index]
                                           .Cells[0].Value.ToString();
                if (objBibliotheca.bibliothecaDelete(strDelRow) == true)
                {
                    MessageBox.Show("成功删除", "提示信息",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = objBibliotheca.getBibliothecaDataAll();
                }
                else
                {
                    MessageBox.Show("删除失败,请重试!", "提示信息",
                                 MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            string currentBookNo = null;
            currentBookNo = dataGridView1.Rows[dataGridView1.CurrentRow.Index]
                                                    .Cells[0].Value.ToString();
            frmBibliothecaInfoEdit bibliothecaInfoEdit =
                                     new frmBibliothecaInfoEdit(currentBookNo);
            bibliothecaInfoEdit.ShowDialog();
            dataGridView1.DataSource = objBibliotheca.getBibliothecaDataAll();
        }

        private void btnBrowseAll_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = objBibliotheca.getBibliothecaDataAll();
            dataGridView1.DataSource = dt.DefaultView;
        }


        private void txtBookName_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = objBibliotheca.getBibliothecaInfoByName(txtBookName.Text.Trim());
        }

        private void txtBibliothecaCode_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = objBibliotheca.getBibliothecaInfoById(txtBibliothecaCode.Text.Trim());
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtBookName_TextChanged_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource = objBibliotheca.getBibliothecaInfoById(txtBookName.Text.Trim());
        }

        
    }
}
