﻿namespace BookUI
{
    partial class frmBibliothecaInfoAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookNumber = new System.Windows.Forms.Label();
            this.txtBibliothecaId = new System.Windows.Forms.TextBox();
            this.cboBookType = new System.Windows.Forms.ComboBox();
            this.dtpPublishDate = new System.Windows.Forms.DateTimePicker();
            this.nudInNumber = new System.Windows.Forms.NumericUpDown();
            this.btnSelectPublisher = new System.Windows.Forms.Button();
            this.lblBookName = new System.Windows.Forms.Label();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.lblBookType = new System.Windows.Forms.Label();
            this.lbPublishData = new System.Windows.Forms.Label();
            this.lblBookPages = new System.Windows.Forms.Label();
            this.lblTotalNumber = new System.Windows.Forms.Label();
            this.txtBookPages = new System.Windows.Forms.TextBox();
            this.lbBookISBN = new System.Windows.Forms.Label();
            this.lblSynopsis = new System.Windows.Forms.Label();
            this.lbAuthor = new System.Windows.Forms.Label();
            this.lblPublisher = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblNowNumber = new System.Windows.Forms.Label();
            this.lblPlace = new System.Windows.Forms.Label();
            this.txtBookISBN = new System.Windows.Forms.TextBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.cboPlace = new System.Windows.Forms.ComboBox();
            this.nudNowNumber = new System.Windows.Forms.NumericUpDown();
            this.txtSynopsis = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            this.btnInStore = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtPublisher = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudInNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNowNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBookNumber
            // 
            this.lblBookNumber.AutoSize = true;
            this.lblBookNumber.Location = new System.Drawing.Point(3, 25);
            this.lblBookNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookNumber.Name = "lblBookNumber";
            this.lblBookNumber.Size = new System.Drawing.Size(65, 12);
            this.lblBookNumber.TabIndex = 0;
            this.lblBookNumber.Text = "书目编号：";
            // 
            // txtBibliothecaId
            // 
            this.txtBibliothecaId.Location = new System.Drawing.Point(71, 22);
            this.txtBibliothecaId.Margin = new System.Windows.Forms.Padding(2);
            this.txtBibliothecaId.Name = "txtBibliothecaId";
            this.txtBibliothecaId.Size = new System.Drawing.Size(353, 21);
            this.txtBibliothecaId.TabIndex = 1;
            // 
            // cboBookType
            // 
            this.cboBookType.FormattingEnabled = true;
            this.cboBookType.Location = new System.Drawing.Point(71, 88);
            this.cboBookType.Margin = new System.Windows.Forms.Padding(2);
            this.cboBookType.Name = "cboBookType";
            this.cboBookType.Size = new System.Drawing.Size(135, 20);
            this.cboBookType.TabIndex = 2;
            this.cboBookType.SelectedValueChanged += new System.EventHandler(this.cboBookType_SelectedValueChanged);
            // 
            // dtpPublishDate
            // 
            this.dtpPublishDate.CustomFormat = "yyyy_MM_dd";
            this.dtpPublishDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPublishDate.Location = new System.Drawing.Point(71, 122);
            this.dtpPublishDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpPublishDate.Name = "dtpPublishDate";
            this.dtpPublishDate.Size = new System.Drawing.Size(135, 21);
            this.dtpPublishDate.TabIndex = 3;
            // 
            // nudInNumber
            // 
            this.nudInNumber.Location = new System.Drawing.Point(71, 189);
            this.nudInNumber.Margin = new System.Windows.Forms.Padding(2);
            this.nudInNumber.Name = "nudInNumber";
            this.nudInNumber.Size = new System.Drawing.Size(133, 21);
            this.nudInNumber.TabIndex = 4;
            this.nudInNumber.ValueChanged += new System.EventHandler(this.nudInNumber_ValueChanged);
            this.nudInNumber.Leave += new System.EventHandler(this.nudInNumber_Leave);
            // 
            // btnSelectPublisher
            // 
            this.btnSelectPublisher.Location = new System.Drawing.Point(391, 120);
            this.btnSelectPublisher.Margin = new System.Windows.Forms.Padding(2);
            this.btnSelectPublisher.Name = "btnSelectPublisher";
            this.btnSelectPublisher.Size = new System.Drawing.Size(30, 20);
            this.btnSelectPublisher.TabIndex = 5;
            this.btnSelectPublisher.Text = "...";
            this.btnSelectPublisher.UseVisualStyleBackColor = true;
            this.btnSelectPublisher.Click += new System.EventHandler(this.btnSelectPublisher_Click);
            // 
            // lblBookName
            // 
            this.lblBookName.AutoSize = true;
            this.lblBookName.Location = new System.Drawing.Point(3, 55);
            this.lblBookName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookName.Name = "lblBookName";
            this.lblBookName.Size = new System.Drawing.Size(65, 12);
            this.lblBookName.TabIndex = 6;
            this.lblBookName.Text = "图书名称：";
            // 
            // txtBookName
            // 
            this.txtBookName.AccessibleDescription = "c";
            this.txtBookName.Location = new System.Drawing.Point(71, 51);
            this.txtBookName.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.Size = new System.Drawing.Size(353, 21);
            this.txtBookName.TabIndex = 7;
            // 
            // lblBookType
            // 
            this.lblBookType.AutoSize = true;
            this.lblBookType.Location = new System.Drawing.Point(3, 90);
            this.lblBookType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookType.Name = "lblBookType";
            this.lblBookType.Size = new System.Drawing.Size(65, 12);
            this.lblBookType.TabIndex = 8;
            this.lblBookType.Text = "图书类型：";
            // 
            // lbPublishData
            // 
            this.lbPublishData.AutoSize = true;
            this.lbPublishData.Location = new System.Drawing.Point(3, 124);
            this.lbPublishData.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPublishData.Name = "lbPublishData";
            this.lbPublishData.Size = new System.Drawing.Size(65, 12);
            this.lbPublishData.TabIndex = 9;
            this.lbPublishData.Text = "出版日期：";
            // 
            // lblBookPages
            // 
            this.lblBookPages.AutoSize = true;
            this.lblBookPages.Location = new System.Drawing.Point(3, 159);
            this.lblBookPages.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookPages.Name = "lblBookPages";
            this.lblBookPages.Size = new System.Drawing.Size(65, 12);
            this.lblBookPages.TabIndex = 10;
            this.lblBookPages.Text = "图书页数：";
            // 
            // lblTotalNumber
            // 
            this.lblTotalNumber.AutoSize = true;
            this.lblTotalNumber.Location = new System.Drawing.Point(3, 193);
            this.lblTotalNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalNumber.Name = "lblTotalNumber";
            this.lblTotalNumber.Size = new System.Drawing.Size(65, 12);
            this.lblTotalNumber.TabIndex = 11;
            this.lblTotalNumber.Text = "待入库量：";
            // 
            // txtBookPages
            // 
            this.txtBookPages.AccessibleDescription = "c";
            this.txtBookPages.Location = new System.Drawing.Point(71, 156);
            this.txtBookPages.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookPages.Name = "txtBookPages";
            this.txtBookPages.Size = new System.Drawing.Size(135, 21);
            this.txtBookPages.TabIndex = 12;
            this.txtBookPages.TextChanged += new System.EventHandler(this.txtBookPages_TextChanged);
            // 
            // lbBookISBN
            // 
            this.lbBookISBN.AutoSize = true;
            this.lbBookISBN.Location = new System.Drawing.Point(3, 225);
            this.lbBookISBN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbBookISBN.Name = "lbBookISBN";
            this.lbBookISBN.Size = new System.Drawing.Size(59, 12);
            this.lbBookISBN.TabIndex = 13;
            this.lbBookISBN.Text = "图书ISBN:";
            // 
            // lblSynopsis
            // 
            this.lblSynopsis.AutoSize = true;
            this.lblSynopsis.Location = new System.Drawing.Point(4, 281);
            this.lblSynopsis.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSynopsis.Name = "lblSynopsis";
            this.lblSynopsis.Size = new System.Drawing.Size(65, 12);
            this.lblSynopsis.TabIndex = 14;
            this.lblSynopsis.Text = "内容简介：";
            // 
            // lbAuthor
            // 
            this.lbAuthor.AutoSize = true;
            this.lbAuthor.Location = new System.Drawing.Point(223, 90);
            this.lbAuthor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbAuthor.Name = "lbAuthor";
            this.lbAuthor.Size = new System.Drawing.Size(41, 12);
            this.lbAuthor.TabIndex = 15;
            this.lbAuthor.Text = "作者：";
            // 
            // lblPublisher
            // 
            this.lblPublisher.AutoSize = true;
            this.lblPublisher.Location = new System.Drawing.Point(223, 125);
            this.lblPublisher.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPublisher.Name = "lblPublisher";
            this.lblPublisher.Size = new System.Drawing.Size(53, 12);
            this.lblPublisher.TabIndex = 16;
            this.lblPublisher.Text = "出版社：";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(223, 163);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(41, 12);
            this.lblPrice.TabIndex = 17;
            this.lblPrice.Text = "价格：";
            // 
            // lblNowNumber
            // 
            this.lblNowNumber.AutoSize = true;
            this.lblNowNumber.Location = new System.Drawing.Point(223, 197);
            this.lblNowNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNowNumber.Name = "lblNowNumber";
            this.lblNowNumber.Size = new System.Drawing.Size(65, 12);
            this.lblNowNumber.TabIndex = 18;
            this.lblNowNumber.Text = "现存数量：";
            // 
            // lblPlace
            // 
            this.lblPlace.AutoSize = true;
            this.lblPlace.Location = new System.Drawing.Point(223, 229);
            this.lblPlace.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(65, 12);
            this.lblPlace.TabIndex = 19;
            this.lblPlace.Text = "藏书地点：";
            // 
            // txtBookISBN
            // 
            this.txtBookISBN.AccessibleDescription = "c";
            this.txtBookISBN.Location = new System.Drawing.Point(71, 222);
            this.txtBookISBN.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookISBN.Multiline = true;
            this.txtBookISBN.Name = "txtBookISBN";
            this.txtBookISBN.Size = new System.Drawing.Size(135, 20);
            this.txtBookISBN.TabIndex = 20;
            // 
            // txtAuthor
            // 
            this.txtAuthor.AccessibleDescription = "c";
            this.txtAuthor.Location = new System.Drawing.Point(284, 88);
            this.txtAuthor.Margin = new System.Windows.Forms.Padding(2);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(139, 21);
            this.txtAuthor.TabIndex = 21;
            // 
            // txtPrice
            // 
            this.txtPrice.AccessibleDescription = "c";
            this.txtPrice.Location = new System.Drawing.Point(284, 156);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(139, 21);
            this.txtPrice.TabIndex = 22;
            this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);
            // 
            // cboPlace
            // 
            this.cboPlace.FormattingEnabled = true;
            this.cboPlace.Location = new System.Drawing.Point(284, 223);
            this.cboPlace.Margin = new System.Windows.Forms.Padding(2);
            this.cboPlace.Name = "cboPlace";
            this.cboPlace.Size = new System.Drawing.Size(139, 20);
            this.cboPlace.TabIndex = 24;
            // 
            // nudNowNumber
            // 
            this.nudNowNumber.Location = new System.Drawing.Point(284, 189);
            this.nudNowNumber.Margin = new System.Windows.Forms.Padding(2);
            this.nudNowNumber.Name = "nudNowNumber";
            this.nudNowNumber.Size = new System.Drawing.Size(139, 21);
            this.nudNowNumber.TabIndex = 25;
            // 
            // txtSynopsis
            // 
            this.txtSynopsis.Location = new System.Drawing.Point(71, 255);
            this.txtSynopsis.Margin = new System.Windows.Forms.Padding(2);
            this.txtSynopsis.Multiline = true;
            this.txtSynopsis.Name = "txtSynopsis";
            this.txtSynopsis.Size = new System.Drawing.Size(353, 98);
            this.txtSynopsis.TabIndex = 26;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(25, 363);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(69, 23);
            this.btnAdd.TabIndex = 27;
            this.btnAdd.Text = "新增（&A）";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(104, 363);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(69, 23);
            this.btnSave.TabIndex = 28;
            this.btnSave.Text = "保存（&S）";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.Location = new System.Drawing.Point(186, 363);
            this.btnCancle.Margin = new System.Windows.Forms.Padding(2);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(69, 23);
            this.btnCancle.TabIndex = 29;
            this.btnCancle.Text = "取消（&C）";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnInStore
            // 
            this.btnInStore.Location = new System.Drawing.Point(272, 363);
            this.btnInStore.Margin = new System.Windows.Forms.Padding(2);
            this.btnInStore.Name = "btnInStore";
            this.btnInStore.Size = new System.Drawing.Size(69, 23);
            this.btnInStore.TabIndex = 30;
            this.btnInStore.Text = "入库（&I)";
            this.btnInStore.UseVisualStyleBackColor = true;
            this.btnInStore.Click += new System.EventHandler(this.btnInStore_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(354, 363);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(69, 23);
            this.btnClose.TabIndex = 31;
            this.btnClose.Text = "关闭（&E）";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtPublisher
            // 
            this.txtPublisher.AccessibleDescription = "c";
            this.txtPublisher.Location = new System.Drawing.Point(284, 121);
            this.txtPublisher.Margin = new System.Windows.Forms.Padding(2);
            this.txtPublisher.Multiline = true;
            this.txtPublisher.Name = "txtPublisher";
            this.txtPublisher.Size = new System.Drawing.Size(111, 20);
            this.txtPublisher.TabIndex = 32;
            // 
            // frmBibliothecaInfoAdd
            // 
            this.AccessibleDescription = "v";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 394);
            this.Controls.Add(this.txtPublisher);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnInStore);
            this.Controls.Add(this.btnCancle);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtSynopsis);
            this.Controls.Add(this.nudNowNumber);
            this.Controls.Add(this.cboPlace);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.txtBookISBN);
            this.Controls.Add(this.lblPlace);
            this.Controls.Add(this.lblNowNumber);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblPublisher);
            this.Controls.Add(this.lbAuthor);
            this.Controls.Add(this.lblSynopsis);
            this.Controls.Add(this.lbBookISBN);
            this.Controls.Add(this.txtBookPages);
            this.Controls.Add(this.lblTotalNumber);
            this.Controls.Add(this.lblBookPages);
            this.Controls.Add(this.lbPublishData);
            this.Controls.Add(this.lblBookType);
            this.Controls.Add(this.txtBookName);
            this.Controls.Add(this.lblBookName);
            this.Controls.Add(this.btnSelectPublisher);
            this.Controls.Add(this.nudInNumber);
            this.Controls.Add(this.dtpPublishDate);
            this.Controls.Add(this.cboBookType);
            this.Controls.Add(this.txtBibliothecaId);
            this.Controls.Add(this.lblBookNumber);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmBibliothecaInfoAdd";
            this.Text = "新增书目";
            this.Load += new System.EventHandler(this.frmBibliothecaInfoAdd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudInNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNowNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookNumber;
        private System.Windows.Forms.TextBox txtBibliothecaId;
        private System.Windows.Forms.ComboBox cboBookType;
        private System.Windows.Forms.DateTimePicker dtpPublishDate;
        private System.Windows.Forms.NumericUpDown nudInNumber;
        private System.Windows.Forms.Button btnSelectPublisher;
        private System.Windows.Forms.Label lblBookName;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.Label lblBookType;
        private System.Windows.Forms.Label lbPublishData;
        private System.Windows.Forms.Label lblBookPages;
        private System.Windows.Forms.Label lblTotalNumber;
        private System.Windows.Forms.TextBox txtBookPages;
        private System.Windows.Forms.Label lbBookISBN;
        private System.Windows.Forms.Label lblSynopsis;
        private System.Windows.Forms.Label lbAuthor;
        private System.Windows.Forms.Label lblPublisher;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblNowNumber;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.TextBox txtBookISBN;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.ComboBox cboPlace;
        private System.Windows.Forms.NumericUpDown nudNowNumber;
        private System.Windows.Forms.TextBox txtSynopsis;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancle;
        private System.Windows.Forms.Button btnInStore;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtPublisher;
    }
}