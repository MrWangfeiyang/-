﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace BookUI
{
    public partial class frmBibliothecaInfoAdd : Form
    { 
        string bookType;
        string publisherISBN;
        BookApp.bibliothecaClass objBibliotheca = new BookApp.bibliothecaClass();
        Regex r = new Regex("^(-?[0-9]*[.]*[0-9]{0,3})$");


        public frmBibliothecaInfoAdd()
        {
            InitializeComponent();
        }
        

       


        private void frmBibliothecaInfoAdd_Load(object sender, EventArgs e)
        {
            cboBookType.DataSource = objBibliotheca.getBookTypeNameAll();
            cboBookType.DisplayMember = "图书类型名称";
            cboBookType.SelectedIndex = -1;
            cboBookType.Text = "请选择";
            cboPlace.DataSource = objBibliotheca.getDepositary();
            cboPlace.DisplayMember = "馆藏地点编号";
            cboPlace.SelectedIndex = -1;
            cboPlace.Text = "请选择";
            btnInStore.Enabled = false;
            nudNowNumber.Enabled = false;
            btnAdd.Enabled = false;
        }

        private bool checkEmpty()
        {
            if (string.IsNullOrEmpty(txtBibliothecaId.Text.Trim()))
            {
                MessageBox.Show("书目编号不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBibliothecaId.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookName.Text.Trim()))
            {
                MessageBox.Show("图书名称不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookName.Focus();
                return false;
            }

            if (cboBookType.Text.Trim() == "请选择" |
                string.IsNullOrEmpty(cboBookType.Text.Trim()))
            {
                MessageBox.Show("请选择图书类型", "提示信息",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboBookType.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtAuthor.Text.Trim()))
            {
                MessageBox.Show("作者不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAuthor.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtPublisher.Text.Trim()))
            {
                MessageBox.Show("出版社不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPublisher.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookPages.Text.Trim()))
            {
                MessageBox.Show("图书页数不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookPages.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtPrice.Text.Trim()))
            {
                MessageBox.Show("价格不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookISBN.Text.Trim()))
            {
                MessageBox.Show("图书馆的ISBN不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookISBN.Focus();
                return false;
            }
            if (cboPlace.Text.Trim() == "请选择" |
                string.IsNullOrEmpty(cboPlace.Text.Trim()))
            {
                MessageBox.Show("藏书地点不能为空", "提示信息",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboPlace.Focus();
                return false;
            }
            return true;
        }

        private void initializationSet()
        {
            txtBibliothecaId.Text = "";
            txtBookName.Text = "";
            txtAuthor.Text = "";
            txtPublisher.Text = "";
            txtBookISBN.Text = "";
            txtBookPages.Text = "";
            txtPrice.Text = "";
            cboBookType.SelectedIndex = -1;
            cboBookType.Text = "请选择";
            nudInNumber.Text = "0";
            nudNowNumber.Text = "0";
            cboPlace.Text = "请选择";
            txtSynopsis.Text = "";
        }
        private void cboBookType_SelectedValueChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = objBibliotheca.getBookTypeId(cboBookType.Text);
            if (dt.Rows.Count != 0)
            {
                bookType = dt.Rows[0][0].ToString();

            }

        }
             private void btnSelectPublisher_Click(object sender,EventArgs e)
        {
            Point publisherLocation=new Point(0,0);
            frmSelectPublisher frmSelect;
            publisherLocation.X = this.Location.X +txtPublisher.Location.X+4;
            publisherLocation.Y = this.Location.Y +txtPublisher.Location.Y+48;
            frmSelect =new frmSelectPublisher(publisherLocation);
            frmSelect.ShowDialog();
            txtPublisher.Text = frmSelect.getTreeViewSelectNode();
            DataTable dt = new DataTable();
            dt = objBibliotheca.getPublisherISBN(txtPublisher.Text);
            if(dt.Rows.Count !=0)
            {
                publisherISBN =dt.Rows[0][0].ToString();
            }
        }

        private void txtBookPages_TextChanged(object sender,EventArgs e)
        {
            if(!string.IsNullOrEmpty(txtBookPages.Text.Trim()))
            {
                
                    if(!r.IsMatch(txtBookPages.Text.Trim()))
                {
                    MessageBox.Show("图书页数只能为数字型数据","提示信息",
                        MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    txtBookPages.Text = "";
                    txtBookPages.Focus();
                    return;
                }
            }
        }


     private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPrice.Text.Trim()))
            {
                if(!r.IsMatch(txtPrice.Text.Trim()))
                {
                MessageBox.Show("价格只能为数字型数据", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Text = "";
                txtPrice.Focus();
                return;


            }
        }
    }


    private void nudInNumber_ValueChanged(object sender,EventArgs e)
   {
               if(Convert.ToInt32(nudInNumber.Value)>0)
                    {
                        nudNowNumber.Value=nudInNumber.Value;
     }
  }

    private void nudInNumber_Leave(object sender,EventArgs e)
   {
      if(Convert.ToInt32(nudInNumber.Value)>0)
       {
     nudNowNumber.Value=nudInNumber.Value;
     }

   }
    private void btnAdd_Click(object sender,EventArgs e)
  {
    initializationSet();
    txtBibliothecaId.Focus();
    btnSave.Enabled=true;
    btnInStore.Enabled=false;
    btnAdd.Enabled=false;

    }
 private void btnSave_Click(object sender,EventArgs e)
        {
            if(checkEmpty() ==false)
            {
                return;
            }
            DataTable dt=new DataTable();
            dt =objBibliotheca.getBibliothecaData(txtBibliothecaId.Text);
            if(dt.Rows.Count==0)
            {
                bool InsertResult =false;
                InsertResult = objBibliotheca 
                               .bibliothecaAdd(txtBibliothecaId.Text.Trim(),
                     txtBookName.Text.Trim(),txtAuthor.Text.Trim(),
                     publisherISBN,txtBookISBN.Text.Trim(),
                     dtpPublishDate.Text.Trim(),
                     Convert.ToInt32(txtBookPages.Text.Trim()),
                     Convert.ToSingle(txtPrice.Text.Trim()),bookType,
                     Convert.ToInt32(nudNowNumber.Text.Trim()),
                     cboPlace.Text.Trim(),txtSynopsis.Text,
                     Convert.ToInt32(nudInNumber.Text.Trim()));
                if(InsertResult ==true)
                {
                    btnSave.Enabled =false;
                    if(MessageBox.Show("新增成功,是否要入库?","提示信息",
                        MessageBoxButtons.YesNo,MessageBoxIcon.Information)
                                                          ==DialogResult.Yes)
                    {
                        btnInStore.Enabled =true;
                        btnAdd.Enabled =true;
                        btnInStore_Click(null,null);
                    }
                    else
                    {
                        btnInStore.Enabled =true;
                        btnAdd.Enabled =true;
                    }
                }
                else
                {
                    MessageBox.Show("新增失败,请重试","提示信息",
                                MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    txtBibliothecaId.Focus();
                    btnSave.Enabled =true;
                }
            }
            else
            {
                MessageBox.Show("已存在同一编号的书目,请核对图书书目","提示信息",
                              MessageBoxButtons.OK,MessageBoxIcon.Warning);

                txtBibliothecaId.Text ="";
                txtBibliothecaId.Focus();
            }
        }





    private void btnCancel_Click(object sender,EventArgs e)
  {
    this.Close();
     
  }

    private void btnInStore_Click(object sender, EventArgs e)
    {

    }

    private void btnClose_Click(object sender, EventArgs e)
    {
        this.Close();
    }


     }

   }

     
  
