﻿namespace BookUI
{
    partial class frmBookTypeManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("图书类型");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBookTypeManage));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.trvList = new System.Windows.Forms.TreeView();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtCurrentSelect = new System.Windows.Forms.TextBox();
            this.txtCurrentCode = new System.Windows.Forms.TextBox();
            this.txtBookTypeExplain = new System.Windows.Forms.TextBox();
            this.txtBookTypeName = new System.Windows.Forms.TextBox();
            this.lblCurrentSelect = new System.Windows.Forms.Label();
            this.txtBookTypeCode = new System.Windows.Forms.TextBox();
            this.lblParentCode = new System.Windows.Forms.Label();
            this.lblCurrentCode = new System.Windows.Forms.Label();
            this.lblBookTypeExplain = new System.Windows.Forms.Label();
            this.lblBookTypeName = new System.Windows.Forms.Label();
            this.lblBookTypeCode = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnAddEql = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAddSub = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnModify = new System.Windows.Forms.ToolStripButton();
            this.btnDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCancel = new System.Windows.Forms.ToolStripButton();
            this.btnExit = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 41);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.splitContainer1.Panel1.Controls.Add(this.trvList);
            this.splitContainer1.Panel1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.splitContainer1.Panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.splitContainer1.Panel1.Tag = "";
            this.splitContainer1.Panel1.UseWaitCursor = true;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textBox4);
            this.splitContainer1.Panel2.Controls.Add(this.txtCurrentSelect);
            this.splitContainer1.Panel2.Controls.Add(this.txtCurrentCode);
            this.splitContainer1.Panel2.Controls.Add(this.txtBookTypeExplain);
            this.splitContainer1.Panel2.Controls.Add(this.txtBookTypeName);
            this.splitContainer1.Panel2.Controls.Add(this.lblCurrentSelect);
            this.splitContainer1.Panel2.Controls.Add(this.txtBookTypeCode);
            this.splitContainer1.Panel2.Controls.Add(this.lblParentCode);
            this.splitContainer1.Panel2.Controls.Add(this.lblCurrentCode);
            this.splitContainer1.Panel2.Controls.Add(this.lblBookTypeExplain);
            this.splitContainer1.Panel2.Controls.Add(this.lblBookTypeName);
            this.splitContainer1.Panel2.Controls.Add(this.lblBookTypeCode);
            this.splitContainer1.Panel2.Cursor = System.Windows.Forms.Cursors.SizeWE;
            this.splitContainer1.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel2_Paint);
            this.splitContainer1.Size = new System.Drawing.Size(437, 264);
            this.splitContainer1.SplitterDistance = 143;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 0;
            // 
            // trvList
            // 
            this.trvList.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.trvList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trvList.Location = new System.Drawing.Point(0, 0);
            this.trvList.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trvList.Name = "trvList";
            treeNode1.Name = "节点0";
            treeNode1.Text = "图书类型";
            this.trvList.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.trvList.Size = new System.Drawing.Size(143, 264);
            this.trvList.TabIndex = 0;
            this.trvList.UseWaitCursor = true;
            this.trvList.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trvList_AfterSelect);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(136, 234);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(141, 21);
            this.textBox4.TabIndex = 13;
            // 
            // txtCurrentSelect
            // 
            this.txtCurrentSelect.Location = new System.Drawing.Point(100, 205);
            this.txtCurrentSelect.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCurrentSelect.Name = "txtCurrentSelect";
            this.txtCurrentSelect.Size = new System.Drawing.Size(177, 21);
            this.txtCurrentSelect.TabIndex = 12;
            // 
            // txtCurrentCode
            // 
            this.txtCurrentCode.Location = new System.Drawing.Point(100, 175);
            this.txtCurrentCode.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtCurrentCode.Name = "txtCurrentCode";
            this.txtCurrentCode.Size = new System.Drawing.Size(177, 21);
            this.txtCurrentCode.TabIndex = 11;
            // 
            // txtBookTypeExplain
            // 
            this.txtBookTypeExplain.Location = new System.Drawing.Point(100, 79);
            this.txtBookTypeExplain.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBookTypeExplain.Multiline = true;
            this.txtBookTypeExplain.Name = "txtBookTypeExplain";
            this.txtBookTypeExplain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBookTypeExplain.Size = new System.Drawing.Size(177, 87);
            this.txtBookTypeExplain.TabIndex = 10;
            // 
            // txtBookTypeName
            // 
            this.txtBookTypeName.Location = new System.Drawing.Point(100, 49);
            this.txtBookTypeName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBookTypeName.Name = "txtBookTypeName";
            this.txtBookTypeName.Size = new System.Drawing.Size(177, 21);
            this.txtBookTypeName.TabIndex = 9;
            // 
            // lblCurrentSelect
            // 
            this.lblCurrentSelect.AutoSize = true;
            this.lblCurrentSelect.Location = new System.Drawing.Point(17, 237);
            this.lblCurrentSelect.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrentSelect.Name = "lblCurrentSelect";
            this.lblCurrentSelect.Size = new System.Drawing.Size(113, 12);
            this.lblCurrentSelect.TabIndex = 8;
            this.lblCurrentSelect.Text = "当前选中的图书类型";
            // 
            // txtBookTypeCode
            // 
            this.txtBookTypeCode.Location = new System.Drawing.Point(100, 20);
            this.txtBookTypeCode.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtBookTypeCode.Name = "txtBookTypeCode";
            this.txtBookTypeCode.Size = new System.Drawing.Size(177, 21);
            this.txtBookTypeCode.TabIndex = 1;
            // 
            // lblParentCode
            // 
            this.lblParentCode.AutoSize = true;
            this.lblParentCode.Location = new System.Drawing.Point(17, 208);
            this.lblParentCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblParentCode.Name = "lblParentCode";
            this.lblParentCode.Size = new System.Drawing.Size(77, 12);
            this.lblParentCode.TabIndex = 7;
            this.lblParentCode.Text = "父项类型编码";
            // 
            // lblCurrentCode
            // 
            this.lblCurrentCode.AutoSize = true;
            this.lblCurrentCode.Location = new System.Drawing.Point(17, 179);
            this.lblCurrentCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrentCode.Name = "lblCurrentCode";
            this.lblCurrentCode.Size = new System.Drawing.Size(77, 12);
            this.lblCurrentCode.TabIndex = 6;
            this.lblCurrentCode.Text = "本级类型编码";
            // 
            // lblBookTypeExplain
            // 
            this.lblBookTypeExplain.AutoSize = true;
            this.lblBookTypeExplain.Location = new System.Drawing.Point(17, 116);
            this.lblBookTypeExplain.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookTypeExplain.Name = "lblBookTypeExplain";
            this.lblBookTypeExplain.Size = new System.Drawing.Size(77, 12);
            this.lblBookTypeExplain.TabIndex = 5;
            this.lblBookTypeExplain.Text = "图书类型说明";
            // 
            // lblBookTypeName
            // 
            this.lblBookTypeName.AutoSize = true;
            this.lblBookTypeName.Location = new System.Drawing.Point(17, 53);
            this.lblBookTypeName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookTypeName.Name = "lblBookTypeName";
            this.lblBookTypeName.Size = new System.Drawing.Size(77, 12);
            this.lblBookTypeName.TabIndex = 4;
            this.lblBookTypeName.Text = "图书类型名称";
            // 
            // lblBookTypeCode
            // 
            this.lblBookTypeCode.AutoSize = true;
            this.lblBookTypeCode.Location = new System.Drawing.Point(17, 23);
            this.lblBookTypeCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBookTypeCode.Name = "lblBookTypeCode";
            this.lblBookTypeCode.Size = new System.Drawing.Size(77, 12);
            this.lblBookTypeCode.TabIndex = 3;
            this.lblBookTypeCode.Text = "图书类型代码";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAddEql,
            this.toolStripSeparator1,
            this.btnAddSub,
            this.toolStripSeparator2,
            this.btnModify,
            this.btnDelete,
            this.toolStripSeparator3,
            this.btnSave,
            this.toolStripSeparator4,
            this.btnCancel,
            this.btnExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(437, 41);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnAddEql
            // 
            this.btnAddEql.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnAddEql.Image = ((System.Drawing.Image)(resources.GetObject("btnAddEql.Image")));
            this.btnAddEql.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAddEql.Name = "btnAddEql";
            this.btnAddEql.Size = new System.Drawing.Size(84, 38);
            this.btnAddEql.Text = "新增同级类型";
            this.btnAddEql.Click += new System.EventHandler(this.btnAddEql_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 41);
            // 
            // btnAddSub
            // 
            this.btnAddSub.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnAddSub.Image = ((System.Drawing.Image)(resources.GetObject("btnAddSub.Image")));
            this.btnAddSub.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAddSub.Name = "btnAddSub";
            this.btnAddSub.Size = new System.Drawing.Size(84, 38);
            this.btnAddSub.Text = "新增下级类型";
            this.btnAddSub.Click += new System.EventHandler(this.btnAddSub_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 41);
            // 
            // btnModify
            // 
            this.btnModify.Image = ((System.Drawing.Image)(resources.GetObject("btnModify.Image")));
            this.btnModify.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(36, 38);
            this.btnModify.Text = "修改";
            this.btnModify.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(36, 38);
            this.btnDelete.Text = "删除";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 41);
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(36, 38);
            this.btnSave.Text = "保存";
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 41);
            // 
            // btnCancel
            // 
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(36, 38);
            this.btnCancel.Text = "取消";
            this.btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnExit
            // 
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(36, 38);
            this.btnExit.Text = "退出";
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmBookTypeManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 305);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmBookTypeManage";
            this.Text = "图书类型管理";
            this.Activated += new System.EventHandler(this.frmBookTypeManage_Activated);
            this.Load += new System.EventHandler(this.frmBookTypeManage_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtBookTypeCode;
        private System.Windows.Forms.TreeView trvList;
        private System.Windows.Forms.Label lblBookTypeCode;
        private System.Windows.Forms.Label lblBookTypeName;
        private System.Windows.Forms.Label lblBookTypeExplain;
        private System.Windows.Forms.Label lblCurrentSelect;
        private System.Windows.Forms.Label lblParentCode;
        private System.Windows.Forms.Label lblCurrentCode;
        private System.Windows.Forms.TextBox txtBookTypeName;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtCurrentSelect;
        private System.Windows.Forms.TextBox txtCurrentCode;
        private System.Windows.Forms.TextBox txtBookTypeExplain;
        private System.Windows.Forms.ToolStripButton btnAddEql;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnAddSub;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btnModify;
        private System.Windows.Forms.ToolStripButton btnDelete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton btnSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btnCancel;
        private System.Windows.Forms.ToolStripButton btnExit;
    }
}