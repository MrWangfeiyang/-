﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BookUI
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frmUserLogin frmUL = new frmUserLogin(); //新建Login窗口
         
            frmUL.ShowDialog(); //使用模式对话框方法显示frmUserLogin
            if (frmUL.DialogResult == DialogResult.OK) //判断是否登陆成功
            {
                frmUL.Close();
                Application.Run(new frmBookMain());
            }
            else
            {
                Application.Exit();
            }
             
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new frmUserManage());

        }
    }
}
