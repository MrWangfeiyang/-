﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmBookTypeManage : Form
    {
        public frmBookTypeManage()
        {
            InitializeComponent();
        }


        BookApp.bookTypeClass objBookType = new BookApp.bookTypeClass();
        string strFlag = "isAdd";

        private void clearTextBox()
        {
            txtBookTypeCode.Text = "";
            txtBookTypeName.Text = "";
            txtBookTypeExplain.Text = "";
            txtCurrentCode.Text = "";
            txtCurrentSelect.Text = "";
        }

        private void setTextBoxState(bool bState)
        {
            txtBookTypeCode.ReadOnly = bState;
            txtBookTypeName.ReadOnly = bState;
            txtBookTypeExplain.ReadOnly = bState;
            txtCurrentCode.ReadOnly = bState;
            txtCurrentSelect.ReadOnly = bState;
        }

        private void setButtonState(bool bState)
        {
            btnAddEql.Enabled = bState;
            btnModify.Enabled = bState;
            btnDelete.Enabled = bState;
            btnSave.Enabled = !bState;
            btnCancel.Enabled = !bState;
        }

        private void initializeTree()
        {
            DataTable dt = new DataTable();
            DataView dvList = null;
            dt = objBookType.getBookType();
            dvList = dt.DefaultView;
            objBookType.initTrvTree(trvList.Nodes, "-1", dvList);
            //初始化treeView控制的各个节点
            trvList.Nodes[0].Tag = new BookApp.treeNodeData("","图书类型","","0","");
            objBookType.initTrvTree(trvList.Nodes, "0", dvList);

        }
        private void frmBookTypeManage_Load(object sender, EventArgs e)
        {
            initializeTree();
            setButtonState(true);
            setTextBoxState(true);
            txtBookTypeCode.ReadOnly = true;
        }

        private void frmBookTypeManage_Activated(object sender, EventArgs e)
        {
            trvList.Nodes[0].Expand();
            trvList.SelectedNode = trvList.Nodes[0];

        }

        private void trvList_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
        {
            //获取当前节点的数据
            BookApp.treeNodeData currentTreeNode =
                (BookApp.treeNodeData)trvList.SelectedNode.Tag;
            if (trvList.SelectedNode.Text != "图书类型")
            {
                txtBookTypeCode.Text = currentTreeNode.BookTypeCode;
                txtBookTypeName.Text = currentTreeNode.BookTypeName;
                txtBookTypeExplain.Text = currentTreeNode.BookTypeExplain;
                txtBookTypeCode.Text = currentTreeNode.ItemIndex;
                txtCurrentSelect.Text = currentTreeNode.ParentIndex;
                txtCurrentSelect.Text = trvList.SelectedNode.Text;
            }
        }

        private void btnAddEql_Click(object sender, EventArgs e)
        {
            strFlag = "isAdd";
            clearTextBox();
            setButtonState(false);
            setTextBoxState(false);
            txtCurrentSelect.Text =
                ((BookApp.treeNodeData)trvList.SelectedNode.Tag).ParentIndex;
            txtCurrentCode.Text = txtCurrentSelect.Text;
            txtBookTypeCode.Focus();
        }

        private void btnAddSub_Click(object sender, EventArgs e)
        {
            strFlag = "isAdd";
            clearTextBox();
            setButtonState(false);
            setTextBoxState(false);
            txtCurrentSelect.ReadOnly = true;
            txtCurrentSelect.Text =
                ((BookApp.treeNodeData)trvList.SelectedNode.Tag).ItemIndex;
            txtCurrentCode.Text = txtCurrentSelect.Text;
            txtBookTypeCode.Focus();
        }

        private void btnModify_Click(System.Object sender, System.EventArgs e)
        {
            strFlag = "isModify";
            setTextBoxState(false);
            setButtonState(false);
            txtBookTypeCode.Enabled = false;
            txtBookTypeName.Focus();
        }

        private void btnSave_Click(System.Object sender, System.EventArgs e)
        {
            if (strFlag == "isAdd")
            {
                if (trvList.SelectedNode == null == false)
                {
                    if(objBookType.saveForAdd(txtBookTypeCode.Text.Trim(),
                        txtBookTypeName.Text.Trim(), txtBookTypeExplain.Text.Trim(),
                        txtCurrentCode.Text.Trim(), txtCurrentSelect.Text.Trim()) == true)
                    {
                        trvList.Nodes.Clear();
                        trvList.Nodes.Add("图书类型");
                        initializeTree();
                        trvList.Nodes[0].Expand();

                    }
                }
            }
            else
            {
                if (trvList.SelectedNode == null == false)
                {
                    if (objBookType.saveForEdit(txtBookTypeCode.Text.Trim(),
                        txtBookTypeName.Text.Trim(), txtBookTypeExplain.Text.Trim(),
                        txtCurrentCode.Text.Trim(), txtCurrentSelect.Text.Trim()) == true)
                    {
                        trvList.Nodes.Clear();
                        trvList.Nodes.Add("图书类型");
                        initializeTree();
                        trvList.Nodes[0].Expand();
                    }
                }
            }
            setButtonState(true);
            setTextBoxState(true);

        }

        private void btnDelete_Click(System.Object sender, System.EventArgs e)
        {
            if (trvList.SelectedNode.Text.Trim() != "图书类型")
            {
                //不能删除具有子节点的节点
                if (trvList.SelectedNode.Nodes.Count != 0)
                {
                    MessageBox.Show("请先删除该项的全部子项", "提示信息",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
                else
                {
                    DialogResult result = MessageBox.Show("你确认删除此数据? ", "删除",
                        MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    if (result == DialogResult.OK)
                    {
                        //生成SQL语句更新数据
                        objBookType.deleteData(txtBookTypeCode.Text.Trim());
                        clearTextBox();
                        trvList.Nodes.Clear();
                        trvList.Nodes.Add("图书类型");
                        initializeTree();
                    }
                }
            }
            else
            {
                MessageBox.Show("请先选择需要删除的节点", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancel_Click(System.Object sender, System.EventArgs e)
        {
            setButtonState(true);
            setTextBoxState(true);
            txtCurrentSelect.ReadOnly = true;
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
