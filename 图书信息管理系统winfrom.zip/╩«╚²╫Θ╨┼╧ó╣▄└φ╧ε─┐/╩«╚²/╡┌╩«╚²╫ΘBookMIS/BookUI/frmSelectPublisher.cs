﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmSelectPublisher : Form
    {
       
        BookApp.bibliothecaClass objBibliotheca = new BookApp.bibliothecaClass();
        Point startLocation;

        public frmSelectPublisher(Point winLocation)
        {
            InitializeComponent();
            startLocation=winLocation;
        }

        public frmSelectPublisher()
        {
            // TODO: Complete member initialization
        }

        private void frmSelectPublisher_Load(object sender,EventArgs e)
        {
            TreeNode tempNode;
            DataTable dt=new DataTable();
            int i=0;
            this.FormBorderStyle=FormBorderStyle.None;
            this.Location=new Point(startLocation.X,startLocation.Y);
            dt=objBibliotheca.getPublisherName();
            for(i=0;i<=dt.Rows.Count-1;i++)
            {
                tempNode=new TreeNode();
                tempNode.Text=dt.Rows[i]["出版社名称"].ToString();
                tvPublisherList.Nodes.Add(tempNode);
            }

        }

        public string getTreeViewSelectNode()
        {
            TreeNode Node=default(TreeNode);
            Node=this.tvPublisherList.SelectedNode;
            return Node.Text;
    }

        private void tvPublisherList_DoubleClick(object sender,EventArgs e)
        {
            this.DialogResult=DialogResult.Yes;
        }
}
}