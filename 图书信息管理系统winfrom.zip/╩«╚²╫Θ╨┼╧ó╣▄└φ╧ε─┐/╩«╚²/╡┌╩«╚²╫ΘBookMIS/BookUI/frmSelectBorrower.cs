﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmSelectBorrower : Form
    {
       
        BookApp.loanClass objLoan = new BookApp.loanClass();
        DataTable dt = new DataTable();
        Point startLocation;

        public frmSelectBorrower(Point winLocation)
        {
            InitializeComponent();
            startLocation = winLocation;
        }
        public string getBorrowerId()
        {
            return dt.Rows[dataGridView1.CurrentRow.Index]["借阅者编号"].ToString();
        }
        private void frmSelectBorrower_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Location = new Point(startLocation.X, startLocation.Y);
            dt = objLoan.getBorrowerInfo("");
            dataGridView1.DataSource = dt.DefaultView;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            this.DialogResult=DialogResult.Yes;
        }
    }
}
