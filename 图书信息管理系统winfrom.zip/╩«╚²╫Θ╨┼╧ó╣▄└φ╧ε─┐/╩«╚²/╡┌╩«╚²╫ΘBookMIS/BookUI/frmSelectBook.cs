﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmSelectBook : Form
    {
        public frmSelectBook()
        {
            InitializeComponent();
        }
        BookApp.loanClass objLoan = new BookApp.loanClass();
        DataTable dt = new DataTable();
        Point startLocation;

        public frmSelectBook(Point winLocation)
        {
            InitializeComponent();
            startLocation = winLocation;
        }
        public string getBookId()
        {
            return dt.Rows[dataGridView1.CurrentRow.Index]["图书条码"].ToString();
        }

        private void frmSelectBook_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Location = new Point(startLocation.X, startLocation.Y);
            dt = objLoan.getBookInfo("");
            dataGridView1.DataSource = dt.DefaultView;
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            this.DialogResult=DialogResult.Yes;
        }
    }
}
