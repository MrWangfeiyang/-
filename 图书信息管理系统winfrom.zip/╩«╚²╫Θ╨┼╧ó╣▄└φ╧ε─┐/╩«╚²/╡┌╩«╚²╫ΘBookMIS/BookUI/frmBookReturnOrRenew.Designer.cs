﻿namespace BookUI
{
    partial class frmBookReturnOrRenew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBorrowerId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGetBorrowerId = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.txtPublisher = new System.Windows.Forms.TextBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.txtBookBarcode = new System.Windows.Forms.TextBox();
            this.btnGetBookBarcode = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBookRenew = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnBookReturn = new System.Windows.Forms.Button();
            this.dgLoanInfo = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLoanInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtBorrowerId);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnGetBorrowerId);
            this.groupBox1.Location = new System.Drawing.Point(5, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(246, 49);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "凭证续借或归还";
            // 
            // txtBorrowerId
            // 
            this.txtBorrowerId.Location = new System.Drawing.Point(87, 20);
            this.txtBorrowerId.Margin = new System.Windows.Forms.Padding(2);
            this.txtBorrowerId.Name = "txtBorrowerId";
            this.txtBorrowerId.Size = new System.Drawing.Size(115, 21);
            this.txtBorrowerId.TabIndex = 7;
            this.txtBorrowerId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBorrowerId_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "借阅者编号：";
            // 
            // btnGetBorrowerId
            // 
            this.btnGetBorrowerId.Location = new System.Drawing.Point(204, 20);
            this.btnGetBorrowerId.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetBorrowerId.Name = "btnGetBorrowerId";
            this.btnGetBorrowerId.Size = new System.Drawing.Size(31, 22);
            this.btnGetBorrowerId.TabIndex = 5;
            this.btnGetBorrowerId.Text = "...";
            this.btnGetBorrowerId.UseVisualStyleBackColor = true;
            this.btnGetBorrowerId.Click += new System.EventHandler(this.btnGetBorrowerId_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAuthor);
            this.groupBox2.Controls.Add(this.txtPublisher);
            this.groupBox2.Controls.Add(this.txtBookName);
            this.groupBox2.Controls.Add(this.txtBookBarcode);
            this.groupBox2.Controls.Add(this.btnGetBookBarcode);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(261, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(159, 207);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "凭书续借或归还";
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(13, 182);
            this.txtAuthor.Margin = new System.Windows.Forms.Padding(2);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(137, 21);
            this.txtAuthor.TabIndex = 14;
            // 
            // txtPublisher
            // 
            this.txtPublisher.Location = new System.Drawing.Point(13, 135);
            this.txtPublisher.Margin = new System.Windows.Forms.Padding(2);
            this.txtPublisher.Name = "txtPublisher";
            this.txtPublisher.Size = new System.Drawing.Size(137, 21);
            this.txtPublisher.TabIndex = 13;
            // 
            // txtBookName
            // 
            this.txtBookName.Location = new System.Drawing.Point(13, 89);
            this.txtBookName.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.Size = new System.Drawing.Size(137, 21);
            this.txtBookName.TabIndex = 12;
            // 
            // txtBookBarcode
            // 
            this.txtBookBarcode.Location = new System.Drawing.Point(13, 42);
            this.txtBookBarcode.Margin = new System.Windows.Forms.Padding(2);
            this.txtBookBarcode.Name = "txtBookBarcode";
            this.txtBookBarcode.Size = new System.Drawing.Size(103, 21);
            this.txtBookBarcode.TabIndex = 8;
            this.txtBookBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBookBarcode_KeyDown);
            // 
            // btnGetBookBarcode
            // 
            this.btnGetBookBarcode.Location = new System.Drawing.Point(119, 42);
            this.btnGetBookBarcode.Margin = new System.Windows.Forms.Padding(2);
            this.btnGetBookBarcode.Name = "btnGetBookBarcode";
            this.btnGetBookBarcode.Size = new System.Drawing.Size(31, 22);
            this.btnGetBookBarcode.TabIndex = 8;
            this.btnGetBookBarcode.Text = "...";
            this.btnGetBookBarcode.UseVisualStyleBackColor = true;
            this.btnGetBookBarcode.Click += new System.EventHandler(this.btnGetBookBarcode_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 162);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "作者：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 115);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "出版社：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 69);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "图书名称：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 22);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "图书条码：";
            // 
            // btnBookRenew
            // 
            this.btnBookRenew.Location = new System.Drawing.Point(105, 244);
            this.btnBookRenew.Margin = new System.Windows.Forms.Padding(2);
            this.btnBookRenew.Name = "btnBookRenew";
            this.btnBookRenew.Size = new System.Drawing.Size(78, 31);
            this.btnBookRenew.TabIndex = 2;
            this.btnBookRenew.Text = "续借图书(&N)";
            this.btnBookRenew.UseVisualStyleBackColor = true;
            this.btnBookRenew.Click += new System.EventHandler(this.btnBookRenew_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(274, 244);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(78, 31);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "关闭(&C)";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnBookReturn
            // 
            this.btnBookReturn.Location = new System.Drawing.Point(105, 244);
            this.btnBookReturn.Margin = new System.Windows.Forms.Padding(2);
            this.btnBookReturn.Name = "btnBookReturn";
            this.btnBookReturn.Size = new System.Drawing.Size(78, 31);
            this.btnBookReturn.TabIndex = 4;
            this.btnBookReturn.Text = "归还图书(&R)";
            this.btnBookReturn.UseVisualStyleBackColor = true;
            this.btnBookReturn.Click += new System.EventHandler(this.btnBookReturn_Click);
            // 
            // dgLoanInfo
            // 
            this.dgLoanInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgLoanInfo.Location = new System.Drawing.Point(5, 83);
            this.dgLoanInfo.Margin = new System.Windows.Forms.Padding(2);
            this.dgLoanInfo.Name = "dgLoanInfo";
            this.dgLoanInfo.RowTemplate.Height = 30;
            this.dgLoanInfo.Size = new System.Drawing.Size(246, 139);
            this.dgLoanInfo.TabIndex = 5;
            this.dgLoanInfo.DoubleClick += new System.EventHandler(this.dgLoanInfo_DoubleClick);
            // 
            // frmBookReturnOrRenew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 286);
            this.Controls.Add(this.dgLoanInfo);
            this.Controls.Add(this.btnBookReturn);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnBookRenew);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmBookReturnOrRenew";
            this.Text = "图书续借或归还";
            this.Load += new System.EventHandler(this.frmBookReturnOrRenew_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLoanInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtBorrowerId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGetBorrowerId;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBookRenew;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnBookReturn;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.TextBox txtPublisher;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.TextBox txtBookBarcode;
        private System.Windows.Forms.Button btnGetBookBarcode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgLoanInfo;
    }
}