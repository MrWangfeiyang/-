﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
   public partial class frmUserManage : Form
    {
            BookApp.bookUserClass objUser = new BookApp.bookUserClass();
            string strFlag;
            int currentRow;
            int userID;
       public frmUserManage()
        {
            InitializeComponent();
        }
      

        private void listViewUserSet()
        {
            String strItem;
            ListViewItem item;
            ListViewItem.ListViewSubItem subitem1;
            ListViewItem.ListViewSubItem subitem2;
            ListViewItem.ListViewSubItem subitem3;
            DataTable tempTable;
            tempTable = objUser.getUserInfoAll();
            listViewUser.Items.Clear();
            listViewUser.Refresh();
            for (int i = 0; i < tempTable.Rows.Count; i++)
            {
                strItem = tempTable.Rows[i][0].ToString();
                item = new ListViewItem(strItem);//用户编号
                subitem1 = new ListViewItem.ListViewSubItem(item, tempTable.Rows[i][1].ToString());//用户名
                subitem2 = new ListViewItem.ListViewSubItem(item, tempTable.Rows[i][2].ToString());//密码
                subitem3 = new ListViewItem.ListViewSubItem(item, tempTable.Rows[i][3].ToString());//ID
                item.SubItems.Add(subitem1);
                item.SubItems.Add(subitem2);
                item.SubItems.Add(subitem3);
                listViewUser.Items.Add(item);

            }
        }
       

            private void listViewItemSelect()
            {
                if (listViewUser.FocusedItem!=null)
                {
                    txtListNum.Text=listViewUser.FocusedItem.SubItems[0].Text.ToString();
                    txtUserName.Text=listViewUser.FocusedItem.SubItems[1].Text.ToString();
                    txtUserPassword.Text=listViewUser.FocusedItem.SubItems[2].Text.ToString();
                    userID=int.Parse (listViewUser.FocusedItem.SubItems[3].Text.ToString());
                }
            }


        private void frmUserManage_Load(object sender,EventArgs e)
        {
            listViewUser.Columns.Add("用户编号");
            listViewUser.Columns.Add("用户名称");
            listViewUser.Columns.Add("用户密码");
            listViewUser.Columns.Add("");
            listViewUser.Columns[0].Width=100;
            listViewUser.Columns[1].Width=100;
            listViewUser.Columns[2].Width=100;
            listViewUser.Columns[3].Width=0;
            listViewUserSet();
            listViewUser.Items[0].Selected=true;
            listViewUser.Items[0].Focused=true;
            listViewItemSelect();
            strFlag="";
            tsbSave.Enabled=false;
            tsbCancel.Enabled=false;
            setControlReadOnly(true);
        }


        private void setControlReadOnly(bool bState)
        {
            txtListNum.ReadOnly=bState;
            txtUserName.ReadOnly=bState;
            txtUserPassword.ReadOnly=bState;
        }
        private bool checkEmpty()
        {
            if(txtListNum.Text.Trim().Length==0)
            {
                MessageBox .Show("用户编号不能为空,请输入用户编号!","提示信息");
                txtListNum.Focus();
                return false;
            }
            if(txtUserName.Text.Trim().Length==0)
            {
                MessageBox .Show("用户名不能为空,请输入用户编号!","提示信息");
                 txtUserName.Focus();
                 return false;
        
            }
            if(txtUserPassword.Text.Trim().Length==0)
            {
                MessageBox .Show("密码不能为空,请输入密码!","提示信息");
                txtUserPassword.Focus();
                return false;
            }
            return true;
        }
        private bool checkRepeat()
        {
            DataTable tempTable;
            tempTable =objUser.getUserInfoByListNum(txtListNum.Text.Trim());
          if (tempTable.Rows.Count >0)
            {
                MessageBox .Show("用户编号已存在,请重新输入用户编号!","提示信息");
                return false;
            }

            tempTable =objUser.getUserInfo(txtUserName.Text.Trim());
            if(tempTable .Rows.Count>0)
            {
                 MessageBox .Show("该用户已存在,请重新输入用户名!","提示信息");
                 return false;
            }
             return true;
        }

         private void insertRecord()
         {
            try
            {
               if(objUser.userAdd(txtListNum.Text.Trim(),txtUserName.Text.Trim(),txtUserPassword.Text.Trim()))
           {
                 MessageBox.Show("已成功新增一个用户","提示信息");
                            listViewUserSet();
                 strFlag="";
                 listViewUser.Focus();
                 listViewUser.Items[listViewUser.Items.Count-1].Selected=true;
                 listViewUser.Items[listViewUser.Items.Count-1].Focused=true;
                 listViewItemSelect();
               }
           }
            catch(Exception ex)
           {
                 MessageBox.Show(ex.Message,"错误提示信息");
                 return;
               }
           }

        private void editRecord()
        {
            try
            {
                if(objUser.userInfoEdit(txtListNum.Text.Trim(),
                    txtUserName.Text.Trim(),
                    txtUserPassword.Text.Trim(),userID))
                {
                    MessageBox.Show("已成功修改一条用户记录","提示信息");
                    listViewUserSet();
                    strFlag = "";
                    listViewUser.Focus();
                    listViewUser.Items[currentRow].Selected = true;
                    listViewUser.Items[currentRow].Focused = true;
                    listViewItemSelect();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"错误提示信息");
                return;
            }
        }
           
        private void tsbAdd_Click(object sender, EventArgs e)
        {
            strFlag = "Add";
            tsbSave.Enabled = true;
            tsbCancel.Enabled = true;
            tsbAdd.Enabled = false;
            tsbEdit.Enabled = false;
            tsbDelete.Enabled = false;
            txtListNum.Text = "";
            txtUserName.Text = "";
            txtUserPassword.Text = "";
            txtListNum.Focus();
            setControlReadOnly(false);
        }
        private void tsbEdit_Click(object sender, EventArgs e)
        {
            strFlag = "Edit";
            tsbSave.Enabled = true;
            tsbCancel.Enabled = true;
            tsbAdd.Enabled = false;
            tsbEdit.Enabled = false;
            tsbDelete.Enabled = false;
            currentRow = listViewUser.FocusedItem.Index;
            txtListNum.Focus();
            setControlReadOnly(false);
        }
        private void tsbDelete_Click(object sender, EventArgs e)
        {
            if (listViewUser.FocusedItem != null)
            {
                if (MessageBox.Show("确实要删除该用户吗?", "删除提示信息",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) ==
                                                DialogResult.Cancel)
                {
                    return;
                }
                else
                {
                    objUser.userDataDelete(listViewUser.FocusedItem.Text.ToString());
                    listViewUserSet();
                    listViewUser.Items[0].Selected = true;
                    listViewUser.Items[0].Focused = true;
                    listViewItemSelect();
                }
            }
            else
            {
                MessageBox.Show("请指定要删除的对象!", "错误提示信息");
            }
        }
        private void tsbSave_Click(object sender,EventArgs e)
        {
             switch (strFlag)
           {
                 case"Add":
                         if(checkEmpty()==true && checkRepeat()==true)
                        {
                                 insertRecord();
                        }
                        break;
                 case"Edit":
                        if(checkEmpty()==true)
                        {
                                 editRecord();
                        }
                        break;
                        }
                        tsbSave.Enabled=false;
                        tsbCancel.Enabled=false;
                        tsbAdd.Enabled=true;
                        tsbEdit.Enabled=true;
                        tsbDelete.Enabled = true;
                        setControlReadOnly(true);
                       }


          private void tsbCancel_Click(object sender,EventArgs e)
           {
                 strFlag="";
                 listViewUser.Focus();
                 listViewUser.Items[0].Selected=true;
                 listViewUser.Items[0].Focused=true;
                 listViewItemSelect();
                 setControlReadOnly(true);
                 }

         private void frmUserManage_KeyPress(object sender,KeyPressEventArgs e)
        {
               if(e.KeyChar==(char)Keys.Enter)
               {
                      e.Handled=true;
                      SendKeys.Send("{TAB}");
                   }
             }

         private void setKey(KeyEventArgs e)
         {
              if(e.KeyCode==Keys.Up || e.KeyCode==Keys.Down)
           {
                e.Handled=true;
           }
            switch(e.KeyCode)
            {
                case Keys.Down:
                     SendKeys.Send("{TAB}");
                     break;
                  case Keys.Up:
                     SendKeys.Send("+{TAB}");
                     break;
                }
           }

         private void tsbClose_Click(object sender, EventArgs e)
         {
             if (MessageBox.Show("你确定要退出用户管理程序吗?", "退出提示信息",
        MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
             {
                 Application.Exit();
             }
         }

         private void listViewUser_Click(object sender, EventArgs e)
         {
             listViewItemSelect();
         }

        
    }

}
