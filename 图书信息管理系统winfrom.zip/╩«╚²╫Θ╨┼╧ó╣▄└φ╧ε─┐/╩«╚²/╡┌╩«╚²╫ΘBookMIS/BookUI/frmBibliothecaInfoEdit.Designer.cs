﻿namespace BookUI
{
    partial class frmBibliothecaInfoEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBookNumber = new System.Windows.Forms.Label();
            this.txtBibliothecaId = new System.Windows.Forms.TextBox();
            this.cboBookType = new System.Windows.Forms.ComboBox();
            this.dtpPublishDate = new System.Windows.Forms.DateTimePicker();
            this.nudInNumber = new System.Windows.Forms.NumericUpDown();
            this.btnSelectPublisher = new System.Windows.Forms.Button();
            this.lblBookName = new System.Windows.Forms.Label();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.lblBookType = new System.Windows.Forms.Label();
            this.lbAuthor = new System.Windows.Forms.Label();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.lbPublishData = new System.Windows.Forms.Label();
            this.lblPublisher = new System.Windows.Forms.Label();
            this.txtPublisher = new System.Windows.Forms.TextBox();
            this.txtBookPages = new System.Windows.Forms.TextBox();
            this.lblBookPages = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblTotalNumber = new System.Windows.Forms.Label();
            this.lblNowNumber = new System.Windows.Forms.Label();
            this.nudNowNumber = new System.Windows.Forms.NumericUpDown();
            this.lbBookISBN = new System.Windows.Forms.Label();
            this.txtBookISBN = new System.Windows.Forms.TextBox();
            this.lblPlace = new System.Windows.Forms.Label();
            this.cboPlace = new System.Windows.Forms.ComboBox();
            this.lblSynopsis = new System.Windows.Forms.Label();
            this.txtSynopsis = new System.Windows.Forms.TextBox();
            this.btnSava = new System.Windows.Forms.Button();
            this.btnCancle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudInNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNowNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBookNumber
            // 
            this.lblBookNumber.AutoSize = true;
            this.lblBookNumber.Location = new System.Drawing.Point(4, 38);
            this.lblBookNumber.Name = "lblBookNumber";
            this.lblBookNumber.Size = new System.Drawing.Size(98, 18);
            this.lblBookNumber.TabIndex = 0;
            this.lblBookNumber.Text = "书目编号：";
            // 
            // txtBibliothecaId
            // 
            this.txtBibliothecaId.Location = new System.Drawing.Point(106, 33);
            this.txtBibliothecaId.Name = "txtBibliothecaId";
            this.txtBibliothecaId.Size = new System.Drawing.Size(528, 28);
            this.txtBibliothecaId.TabIndex = 1;
            // 
            // cboBookType
            // 
            this.cboBookType.FormattingEnabled = true;
            this.cboBookType.Location = new System.Drawing.Point(106, 132);
            this.cboBookType.Name = "cboBookType";
            this.cboBookType.Size = new System.Drawing.Size(200, 26);
            this.cboBookType.TabIndex = 2;
            this.cboBookType.SelectedValueChanged += new System.EventHandler(this.cboBookType_SelectedValueChanged);
            // 
            // dtpPublishDate
            // 
            this.dtpPublishDate.CausesValidation = false;
            this.dtpPublishDate.CustomFormat = "yyyy-MM-dd";
            this.dtpPublishDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPublishDate.Location = new System.Drawing.Point(106, 182);
            this.dtpPublishDate.Name = "dtpPublishDate";
            this.dtpPublishDate.Size = new System.Drawing.Size(200, 28);
            this.dtpPublishDate.TabIndex = 3;
            // 
            // nudInNumber
            // 
            this.nudInNumber.Location = new System.Drawing.Point(106, 284);
            this.nudInNumber.Name = "nudInNumber";
            this.nudInNumber.Size = new System.Drawing.Size(200, 28);
            this.nudInNumber.TabIndex = 4;
            // 
            // btnSelectPublisher
            // 
            this.btnSelectPublisher.Location = new System.Drawing.Point(591, 181);
            this.btnSelectPublisher.Name = "btnSelectPublisher";
            this.btnSelectPublisher.Size = new System.Drawing.Size(43, 30);
            this.btnSelectPublisher.TabIndex = 5;
            this.btnSelectPublisher.Text = "...";
            this.btnSelectPublisher.UseVisualStyleBackColor = true;
            this.btnSelectPublisher.Click += new System.EventHandler(this.btnSelectPublisher_Click);
            // 
            // lblBookName
            // 
            this.lblBookName.AutoSize = true;
            this.lblBookName.Location = new System.Drawing.Point(4, 82);
            this.lblBookName.Name = "lblBookName";
            this.lblBookName.Size = new System.Drawing.Size(98, 18);
            this.lblBookName.TabIndex = 6;
            this.lblBookName.Text = "图书名称：";
            // 
            // txtBookName
            // 
            this.txtBookName.Location = new System.Drawing.Point(106, 76);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.Size = new System.Drawing.Size(528, 28);
            this.txtBookName.TabIndex = 7;
            // 
            // lblBookType
            // 
            this.lblBookType.AutoSize = true;
            this.lblBookType.Location = new System.Drawing.Point(4, 136);
            this.lblBookType.Name = "lblBookType";
            this.lblBookType.Size = new System.Drawing.Size(98, 18);
            this.lblBookType.TabIndex = 8;
            this.lblBookType.Text = "图书类型：";
            // 
            // lbAuthor
            // 
            this.lbAuthor.AutoSize = true;
            this.lbAuthor.Location = new System.Drawing.Point(338, 136);
            this.lbAuthor.Name = "lbAuthor";
            this.lbAuthor.Size = new System.Drawing.Size(62, 18);
            this.lbAuthor.TabIndex = 9;
            this.lbAuthor.Text = "作者：";
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(426, 132);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(208, 28);
            this.txtAuthor.TabIndex = 10;
            // 
            // lbPublishData
            // 
            this.lbPublishData.AutoSize = true;
            this.lbPublishData.Location = new System.Drawing.Point(4, 188);
            this.lbPublishData.Name = "lbPublishData";
            this.lbPublishData.Size = new System.Drawing.Size(98, 18);
            this.lbPublishData.TabIndex = 11;
            this.lbPublishData.Text = "出版日期：";
            // 
            // lblPublisher
            // 
            this.lblPublisher.AutoSize = true;
            this.lblPublisher.Location = new System.Drawing.Point(338, 188);
            this.lblPublisher.Name = "lblPublisher";
            this.lblPublisher.Size = new System.Drawing.Size(80, 18);
            this.lblPublisher.TabIndex = 12;
            this.lblPublisher.Text = "出版社：";
            // 
            // txtPublisher
            // 
            this.txtPublisher.Location = new System.Drawing.Point(426, 182);
            this.txtPublisher.Name = "txtPublisher";
            this.txtPublisher.Size = new System.Drawing.Size(168, 28);
            this.txtPublisher.TabIndex = 13;
            // 
            // txtBookPages
            // 
            this.txtBookPages.Location = new System.Drawing.Point(106, 232);
            this.txtBookPages.Name = "txtBookPages";
            this.txtBookPages.Size = new System.Drawing.Size(200, 28);
            this.txtBookPages.TabIndex = 14;
            this.txtBookPages.TextChanged += new System.EventHandler(this.txtBookPages_TextChanged);
            // 
            // lblBookPages
            // 
            this.lblBookPages.AutoSize = true;
            this.lblBookPages.Location = new System.Drawing.Point(4, 237);
            this.lblBookPages.Name = "lblBookPages";
            this.lblBookPages.Size = new System.Drawing.Size(98, 18);
            this.lblBookPages.TabIndex = 15;
            this.lblBookPages.Text = "图书页数：";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(338, 240);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(62, 18);
            this.lblPrice.TabIndex = 16;
            this.lblPrice.Text = "价格：";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(426, 232);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(208, 28);
            this.txtPrice.TabIndex = 17;
            this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);
            // 
            // lblTotalNumber
            // 
            this.lblTotalNumber.AutoSize = true;
            this.lblTotalNumber.Location = new System.Drawing.Point(4, 286);
            this.lblTotalNumber.Name = "lblTotalNumber";
            this.lblTotalNumber.Size = new System.Drawing.Size(98, 18);
            this.lblTotalNumber.TabIndex = 18;
            this.lblTotalNumber.Text = "待入库量：";
            // 
            // lblNowNumber
            // 
            this.lblNowNumber.AutoSize = true;
            this.lblNowNumber.Location = new System.Drawing.Point(338, 290);
            this.lblNowNumber.Name = "lblNowNumber";
            this.lblNowNumber.Size = new System.Drawing.Size(98, 18);
            this.lblNowNumber.TabIndex = 19;
            this.lblNowNumber.Text = "现存数量：";
            // 
            // nudNowNumber
            // 
            this.nudNowNumber.Location = new System.Drawing.Point(426, 282);
            this.nudNowNumber.Name = "nudNowNumber";
            this.nudNowNumber.Size = new System.Drawing.Size(208, 28);
            this.nudNowNumber.TabIndex = 20;
            // 
            // lbBookISBN
            // 
            this.lbBookISBN.AutoSize = true;
            this.lbBookISBN.Location = new System.Drawing.Point(4, 338);
            this.lbBookISBN.Name = "lbBookISBN";
            this.lbBookISBN.Size = new System.Drawing.Size(89, 18);
            this.lbBookISBN.TabIndex = 21;
            this.lbBookISBN.Text = "图书ISBN:";
            // 
            // txtBookISBN
            // 
            this.txtBookISBN.Location = new System.Drawing.Point(106, 333);
            this.txtBookISBN.Name = "txtBookISBN";
            this.txtBookISBN.Size = new System.Drawing.Size(200, 28);
            this.txtBookISBN.TabIndex = 22;
            // 
            // lblPlace
            // 
            this.lblPlace.AutoSize = true;
            this.lblPlace.Location = new System.Drawing.Point(338, 338);
            this.lblPlace.Name = "lblPlace";
            this.lblPlace.Size = new System.Drawing.Size(98, 18);
            this.lblPlace.TabIndex = 23;
            this.lblPlace.Text = "藏书地点：";
            // 
            // cboPlace
            // 
            this.cboPlace.FormattingEnabled = true;
            this.cboPlace.Location = new System.Drawing.Point(426, 333);
            this.cboPlace.Name = "cboPlace";
            this.cboPlace.Size = new System.Drawing.Size(208, 26);
            this.cboPlace.TabIndex = 24;
            // 
            // lblSynopsis
            // 
            this.lblSynopsis.AutoSize = true;
            this.lblSynopsis.Location = new System.Drawing.Point(6, 422);
            this.lblSynopsis.Name = "lblSynopsis";
            this.lblSynopsis.Size = new System.Drawing.Size(98, 18);
            this.lblSynopsis.TabIndex = 25;
            this.lblSynopsis.Text = "内容简介：";
            // 
            // txtSynopsis
            // 
            this.txtSynopsis.Location = new System.Drawing.Point(106, 382);
            this.txtSynopsis.Multiline = true;
            this.txtSynopsis.Name = "txtSynopsis";
            this.txtSynopsis.Size = new System.Drawing.Size(528, 145);
            this.txtSynopsis.TabIndex = 26;
            // 
            // btnSava
            // 
            this.btnSava.Location = new System.Drawing.Point(172, 544);
            this.btnSava.Name = "btnSava";
            this.btnSava.Size = new System.Drawing.Size(104, 34);
            this.btnSava.TabIndex = 27;
            this.btnSava.Text = "保存（&S）";
            this.btnSava.UseVisualStyleBackColor = true;
            this.btnSava.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancle
            // 
            this.btnCancle.Location = new System.Drawing.Point(412, 544);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(104, 34);
            this.btnCancle.TabIndex = 28;
            this.btnCancle.Text = "取消（&C）";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // frmBibliothecaInfoEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 591);
            this.Controls.Add(this.btnCancle);
            this.Controls.Add(this.btnSava);
            this.Controls.Add(this.txtSynopsis);
            this.Controls.Add(this.lblSynopsis);
            this.Controls.Add(this.cboPlace);
            this.Controls.Add(this.lblPlace);
            this.Controls.Add(this.txtBookISBN);
            this.Controls.Add(this.lbBookISBN);
            this.Controls.Add(this.nudNowNumber);
            this.Controls.Add(this.lblNowNumber);
            this.Controls.Add(this.lblTotalNumber);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblBookPages);
            this.Controls.Add(this.txtBookPages);
            this.Controls.Add(this.txtPublisher);
            this.Controls.Add(this.lblPublisher);
            this.Controls.Add(this.lbPublishData);
            this.Controls.Add(this.txtAuthor);
            this.Controls.Add(this.lbAuthor);
            this.Controls.Add(this.lblBookType);
            this.Controls.Add(this.txtBookName);
            this.Controls.Add(this.lblBookName);
            this.Controls.Add(this.btnSelectPublisher);
            this.Controls.Add(this.nudInNumber);
            this.Controls.Add(this.dtpPublishDate);
            this.Controls.Add(this.cboBookType);
            this.Controls.Add(this.txtBibliothecaId);
            this.Controls.Add(this.lblBookNumber);
            this.Name = "frmBibliothecaInfoEdit";
            this.Text = "修改书目数据";
            this.Load += new System.EventHandler(this.frmBibliothecaInfoEdit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudInNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNowNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBookNumber;
        private System.Windows.Forms.TextBox txtBibliothecaId;
        private System.Windows.Forms.ComboBox cboBookType;
        private System.Windows.Forms.DateTimePicker dtpPublishDate;
        private System.Windows.Forms.NumericUpDown nudInNumber;
        private System.Windows.Forms.Button btnSelectPublisher;
        private System.Windows.Forms.Label lblBookName;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.Label lblBookType;
        private System.Windows.Forms.Label lbAuthor;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.Label lbPublishData;
        private System.Windows.Forms.Label lblPublisher;
        private System.Windows.Forms.TextBox txtPublisher;
        private System.Windows.Forms.TextBox txtBookPages;
        private System.Windows.Forms.Label lblBookPages;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblTotalNumber;
        private System.Windows.Forms.Label lblNowNumber;
        private System.Windows.Forms.NumericUpDown nudNowNumber;
        private System.Windows.Forms.Label lbBookISBN;
        private System.Windows.Forms.TextBox txtBookISBN;
        private System.Windows.Forms.Label lblPlace;
        private System.Windows.Forms.ComboBox cboPlace;
        private System.Windows.Forms.Label lblSynopsis;
        private System.Windows.Forms.TextBox txtSynopsis;
        private System.Windows.Forms.Button btnSava;
        private System.Windows.Forms.Button btnCancle;
    }
}