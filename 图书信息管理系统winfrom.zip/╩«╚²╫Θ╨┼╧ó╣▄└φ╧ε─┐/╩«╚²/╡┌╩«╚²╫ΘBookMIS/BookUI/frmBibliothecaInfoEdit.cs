﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace BookUI
{
    public partial class frmBibliothecaInfoEdit : Form
    {
  

        string editBibliothecaId = null;
        string bookType = null;
        string publisherISBN = null;
        BookApp.bibliothecaClass objBibliotheca = new BookApp.bibliothecaClass();
        Regex r = new Regex("^(-?[0-9]*[.]*[0-9]{0,3})$");


        public frmBibliothecaInfoEdit(string bookNo)
        {
            InitializeComponent();  //系统自动生成代码
            editBibliothecaId = bookNo;

        }

        public frmBibliothecaInfoEdit()
        {
            // TODO: Complete member initialization
        }

        private void frmBibliothecaInfoEdit_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            cboBookType.DataSource = objBibliotheca.getBookTypeNameAll();
            cboBookType.DisplayMember = "图书类型名称";
            cboPlace.DataSource = objBibliotheca.getDepositary();
            cboPlace.DisplayMember = "馆藏地点编号";
            dt = objBibliotheca.getBibliothecaData(editBibliothecaId);
            txtBibliothecaId.Text = dt.Rows[0]["书目编号"].ToString();
            txtBookName.Text = dt.Rows[0]["图书名称"].ToString();
            txtAuthor.Text = dt.Rows[0]["作者"].ToString();
            txtPublisher.Text = dt.Rows[0]["出版社名称"].ToString();
            publisherISBN = dt.Rows[0]["出版社名称"].ToString();//必须初始化变量
            txtBookISBN.Text = dt.Rows[0]["ISBN"].ToString();
            dtpPublishDate.Text = Convert.ToDateTime(dt.Rows[0]["出版日期"].ToString() + "-1").ToString();
            txtBookPages.Text = dt.Rows[0]["图书页数"].ToString();
            txtPrice.Text = dt.Rows[0]["价格"].ToString();
            cboBookType.Text = dt.Rows[0]["图书类型名称"].ToString();
            nudInNumber.Text = (object.ReferenceEquals(dt.Rows[0]["总藏书数量"].ToString(),DBNull.Value) ? "0" : dt.Rows[0]["总藏书数量"].ToString());
            nudNowNumber.Text = dt.Rows[0]["现存数量"].ToString();
            cboPlace.Text = dt.Rows[0]["馆藏地点"].ToString();
            txtSynopsis.Text = (string.IsNullOrEmpty(dt.Rows[0]["简介"].ToString()) ? ""
                :dt.Rows[0]["简介"].ToString());
            //getTypeId();//必须初始化变量

        }


        private bool checkEmpty()
        {
            if (string.IsNullOrEmpty(txtBibliothecaId.Text.Trim()))
            {
                MessageBox.Show("书目编号不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBibliothecaId.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookName.Text.Trim()))
            {
                MessageBox.Show("图书名称不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookName.Focus();
                return false;
            }

            if (cboBookType.Text.Trim() == "请选择" |
                string.IsNullOrEmpty(cboBookType.Text.Trim()))
            {
                MessageBox.Show("请选择图书类型", "提示信息",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboBookType.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtAuthor.Text.Trim()))
            {
                MessageBox.Show("作者不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAuthor.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtPublisher.Text.Trim()))
            {
                MessageBox.Show("出版社不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPublisher.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookPages.Text.Trim()))
            {
                MessageBox.Show("图书页数不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookPages.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtPrice.Text.Trim()))
            {
                MessageBox.Show("价格不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtBookISBN.Text.Trim()))
            {
                MessageBox.Show("图书馆的ISBN不能为空", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBookISBN.Focus();
                return false;
            }
            if (cboPlace.Text.Trim() == "请选择" |
                string.IsNullOrEmpty(cboPlace.Text.Trim()))
            {
                MessageBox.Show("藏书地点不能为空", "提示信息",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboPlace.Focus();
                return false;
            }
            return true;
        }


        private string getTypeId()
        {
            DataTable dt = new DataTable();
            dt = objBibliotheca.getBookTypeId(cboBookType.Text);
            if (dt.Rows.Count != 0)
            {
                bookType = dt.Rows[0][0].ToString();
            }

            return bookType;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            if (checkEmpty() == false)
            {
                return;
            }
            dt = objBibliotheca.getPublisherISBN(txtPublisher.Text);
            if (dt.Rows.Count != 0)
            {
                publisherISBN = dt.Rows[0][0].ToString();
            }
            //判断图书编号是否修改了
            if (txtBibliothecaId.Text != editBibliothecaId)
            {
                dt.Clear();
                dt = objBibliotheca.getBibliothecaData(txtBibliothecaId.Text);
                //判断输入的图书编号是否已经存在
                if (dt.Rows.Count == 0)
                {
                    bool updateResult = false;
                    updateResult = objBibliotheca.bibliothecaEditAll(
                        txtBibliothecaId.Text.Trim(),
                        txtBookName.Text.Trim(), txtAuthor.Text.Trim(),
                        publisherISBN,txtBookISBN.Text.Trim(),
                        dtpPublishDate.Text.Trim(),
                        Convert.ToInt32(txtBookPages.Text.Trim()),
                        Convert.ToSingle(txtPrice.Text.Trim()),
                        bookType, Convert.ToInt32(nudInNumber.Text.Trim()),
                        Convert.ToInt32(nudNowNumber.Text.Trim()),
                        cboPlace.Text.Trim(), txtSynopsis.Text,
                        editBibliothecaId);
                    if(updateResult==true)
                    {
                        MessageBox.Show("修改成功", "提示信息", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("书目信息修改失败,请重试! ", "提示信息",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtBibliothecaId.Focus();
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("此书目编号已经存在,请重新输入正确的图书编号",
                        "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtBibliothecaId.Text = "";
                    txtBibliothecaId.Focus();
                }
                //图书编号没有修改的情况下
            }
            else
            {
                bool updateResult = false;
                updateResult = objBibliotheca.bibliothecaEditPart(
                    txtBibliothecaId.Text.Trim(),
                    txtBookName.Text.Trim(), txtAuthor.Text.Trim(),
                    publisherISBN,txtBookISBN.Text.Trim(),
                    dtpPublishDate.Text.Trim(),
                    Convert.ToInt32(txtBookPages.Text.Trim()),
                    Convert.ToSingle(txtPrice.Text.Trim()), bookType,
                    Convert.ToInt32(nudInNumber.Text.Trim()),
                    Convert.ToInt32(nudNowNumber.Text.Trim()),
                    cboPlace.Text.Trim(), txtSynopsis.Text);

                if(updateResult==true)
                {
                    MessageBox.Show("书目信息修改成功", "提示信息",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("书目信息修改失败,请重试! ","提示信息",
                        MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    txtBibliothecaId.Focus();
                    return;
                }

            }
        }

        private void cboBookType_SelectedValueChanged(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = objBibliotheca.getBookTypeId(cboBookType.Text);
            if (dt.Rows.Count != 0)
            {
                bookType = dt.Rows[0][0].ToString();

            }
        }

        private void btnSelectPublisher_Click(object sender, EventArgs e)
        {
            Point publisherLocation = new Point(0, 0);
            frmSelectPublisher frmSelect;
            publisherLocation.X = this.Location.X + txtPublisher.Location.X + 4;
            publisherLocation.Y = this.Location.Y + txtPublisher.Location.Y + 48;
            frmSelect = new frmSelectPublisher(publisherLocation);
            frmSelect.ShowDialog();
            txtPublisher.Text = frmSelect.getTreeViewSelectNode();
            DataTable dt = new DataTable();
            dt = objBibliotheca.getPublisherISBN(txtPublisher.Text);
            if (dt.Rows.Count != 0)
            {
                publisherISBN = dt.Rows[0][0].ToString();
            }
        }

        private void txtBookPages_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBookPages.Text.Trim()))
            {

                if (!r.IsMatch(txtBookPages.Text.Trim()))
                {
                    MessageBox.Show("图书页数只能为数字型数据", "提示信息",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtBookPages.Text = "";
                    txtBookPages.Focus();
                    return;
                }
            }
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPrice.Text.Trim()))
            {
                if (!r.IsMatch(txtPrice.Text.Trim()))
                {
                    MessageBox.Show("价格只能为数字型数据", "提示信息",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtPrice.Text = "";
                    txtPrice.Focus();
                    return;


                }
            }
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
