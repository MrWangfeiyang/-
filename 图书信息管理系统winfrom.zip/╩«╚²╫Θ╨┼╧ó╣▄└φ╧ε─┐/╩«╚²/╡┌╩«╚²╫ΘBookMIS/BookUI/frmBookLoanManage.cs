﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmBookLoanManage : Form
    {
        public frmBookLoanManage()
        {
            InitializeComponent();
        }

        public string loanerName;
        string strCardState;
        string strBibliothecaId;
        string borrowerId;
        string bookBarcode;
        int maxDay;
        int loanNums;
        System.DateTime loanDate;
        System.DateTime returnDate;
        BookApp.loanClass objLoan = new BookApp.loanClass();

        private void frmBookLoanManage_Load(object sender, EventArgs e)
        {
            btnLoan.Enabled = false;
            DataGridViewCellStyle headerStyle=new DataGridViewCellStyle();
            headerStyle.Alignment=
                        System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgLoanInfo.ColumnHeadersDefaultCellStyle = headerStyle;
        }
         private void getBorrower()
         {
             DataTable dt = new DataTable ();
             int maxNum = 0;
             dt = objLoan.getBorrowerInfo(borrowerId );
             strCardState = dt.Rows[0]["借书证状态"].ToString ();
             maxNum = Convert.ToInt32 (dt.Rows[0]["最大借书数量"]);
             switch (strCardState )
             {
                 //判断借书证状态
                 case"有效":
                     //判断读者是否有超期图书
                     if(objLoan.isOverdue(borrowerId ) == true)
                     {
                         int loanTotalNum = 0;
                         loanTotalNum = 
                                Convert .ToInt32 (objLoan .getLoanBookNums(borrowerId));
                         //判断读者是否达到最大借书量
                         if (Convert.ToInt32(loanTotalNum) < Convert.ToInt32(maxNum))
                         {
                             txtBorrowerName.Text = dt.Rows[0]["姓名"].ToString();
                             txtCardState.Text = dt.Rows[0]["借书证状态"].ToString ();
                             txtPermitNums.Text = maxNum.ToString();
                             txtLoanNums.Text = loanTotalNum.ToString ();
                             txtForegift.Text = dt.Rows[0]["押金剩余"].ToString();
                             maxDay = Convert.ToInt32(dt.Rows[0]["最长借书期限"]);
                             gbLoanInfo.Text = txtBorrowerName.Text+"的已借书情况";
                             dgLoanInfo.DataSource = objLoan.getLoanInfo(borrowerId);
                             btnLoan.Enabled = true;
                         }
                         else
                         {
                             MessageBox.Show("你已经达到最大借书量,不能再借了!",
                                             "提示信息",MessageBoxButtons .OK,
                                             MessageBoxIcon.Information );
                             txtBorrowerId.Text = "";
                             txtBorrowerId.Focus();
                             btnLoan.Enabled = false;
                             return;
                         }
                     }
                     else
                     {
                         MessageBox.Show("你已经有超期图书了,请归还再借! ",
                                 "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                             txtBorrowerId.Text = "";
                             txtBorrowerId.Focus();
                         btnLoan.Enabled = false;
                         return;
                     }
                         break;
                         case"挂失":
                             MessageBox.Show("借阅者的借书证已被挂失,不能继续使用! ",
                                 "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                             txtBorrowerId.Text = "";
                             txtBorrowerId.Focus();
                         btnLoan.Enabled = false;
                         return;
                         case "停用":
                            MessageBox.Show("借阅者的借书证已被停用,不能继续使用! ",
                                 "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                             txtBorrowerId.Text = "";
                             txtBorrowerId.Focus();
                         btnLoan.Enabled = false;
                         return;
                  
             }
         }
                         private void getBook()
                         {
                             DataTable dt = new DataTable();
                             dt = objLoan.getBookInfo(bookBarcode);
                             txtBookName.Text = dt.Rows[0]["图书名称"].ToString();
                             txtAuthor.Text = dt.Rows[0]["作者"].ToString();
                             txtTotalNums.Text = dt.Rows[0]["总藏书数量"].ToString();
                             txtNowNums.Text = dt.Rows[0]["现存数量"].ToString ();
                             txtPrice.Text = dt.Rows[0]["价格"].ToString();
                             strBibliothecaId = dt.Rows[0]["节目编号"].ToString();
                         }
        private bool checkEmpty()
        {
            if(string.IsNullOrEmpty(txtBorrowerId.Text))
            {
                MessageBox.Show ("借阅者编号不能为空,请选择借阅者编号!",
                    "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return false;
            }
            if(string.IsNullOrEmpty(txtBookBarcode.Text))
            {
                MessageBox.Show("图书条码不能为空,请选择图书条码!",
                    "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return false;
            }
            return true;
        }
          private void setLoanInfo()
          {
              borrowerId = txtBorrowerId.Text.Trim();
              bookBarcode = txtBookBarcode.Text.Trim();
              loanDate = DateTime.Today;
              returnDate = DateTime .Today.AddDays(maxDay);
              loanNums = 0;
              loanerName ="admin";
          }
         private void bthSelectBorrowerId_Click(object sender,EventArgs e)
         {
             frmSelectBorrower frmBorrowerSelect = default(frmSelectBorrower);
             Point startLocation = default(Point);
             startLocation.X = this.Location.X+txtBorrowerId.Location.X+10;
             startLocation.Y = this.Location.Y+txtBorrowerId.Location.Y+50;
             frmBorrowerSelect = new frmSelectBorrower(startLocation);
             frmBorrowerSelect.ShowDialog();
             borrowerId = frmBorrowerSelect.getBorrowerId();
             txtBorrowerId.Text = borrowerId;
             getBorrower();
         }
         private void bthSelectBookBarcode_Click(object sender, EventArgs e)
         {
             frmSelectBook frmSelectBook = default(frmSelectBook);
             Point startLocation = default(Point);
             startLocation.X = this.Location.X + txtBorrowerId.Location.X + 10;
             startLocation.Y = this.Location.Y + txtBorrowerId.Location.Y + 50;
             frmSelectBook = new frmSelectBook(startLocation);
             frmSelectBook.ShowDialog();
             bookBarcode = frmSelectBook.getBookId();
             txtBookBarcode.Text = bookBarcode;
             getBook();
         }
        private void txtBorrowerId_KeyDown(object sender,KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                borrowerId = txtBorrowerId.Text;
                getBorrower();
            }
        }
            private void txtBookBarcode_KeyDown(object sender,KeyEventArgs e)
            {
                if(e.KeyCode == Keys.Enter)
                {
                    bookBarcode = txtBookBarcode.Text;
                    getBook();
                }
            }

                private void btnLoan_Click(object sender,EventArgs e)
                {
                    if(checkEmpty() == false)
                    {
                        return;
                    }
                    //执行借书操作
                    setLoanInfo();
                    if(objLoan.loanAdd(borrowerId ,bookBarcode ,loanDate,
                        returnDate,loanNums,loanerName))
                    {
                        MessageBox.Show("借书成功!","提示信息",MessageBoxButtons.OK,
                            MessageBoxIcon .Information );
                        //修改借出图书的现存书量
                        objLoan.bookNowNumReduce(strBibliothecaId);
                        objLoan.setBookState(bookBarcode,"借出");
                        btnLoan.Enabled = false;
                        dgLoanInfo.DataSource = null;
                        dgLoanInfo.DataSource = objLoan.getLoanInfo(borrowerId);
                        dgLoanInfo.Refresh();
                    }
                    else
                    {
                        MessageBox .Show("借书失败,请重试!","提示信息",
                            MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
    }

                private void btnClose_Click(object sender, EventArgs e)
                {
                    this.Close();
                }
}          

    }


  
