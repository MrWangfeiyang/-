﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmUserLogin : Form  //对象的代码通常在类中
    {
        BookApp.bookUserClass objUser = new BookApp.bookUserClass();

        private void frmUserLogin_Load(object sender, EventArgs e)
        {
            DataTable dt;
            dt = objUser.getUserName();
            cboUserName.DataSource = dt;
            cboUserName.DisplayMember = "用户信息.用户名";
            cboUserName.ValueMember = "用户名";
            cboUserName.SelectedIndex = -1;
        }

        private void btnLogin_Click(object sender, EventArgs e)
            {
                if(cboUserName.Text.Trim().Length==0)
                {
                    MessageBox.Show("用户名不能为空,请输入用户名！","提示信息");
                    cboUserName.Focus();
                    return;
                }
                DataTable dt = new DataTable();
                dt=objUser.getUserInfo(cboUserName.Text.Trim(),txtPassword.Text.Trim());
                if(dt.Rows.Count!= 0)
                {
                    if(MessageBox.Show("合法用户,登录成功！","提示信息",
                                   MessageBoxButtons.OKCancel ,
                                    MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        frmBookMain.currentUserName = cboUserName.Text.Trim();
                        this.DialogResult = DialogResult.OK;
                    }
                    else 
                    {
                        this.DialogResult=DialogResult.Cancel;
                    }
                }
                 else
            {
                    dt = objUser.getUserInfo(cboUserName.Text.Trim());
                    if(dt.Rows.Count == 0)
                    {
                        MessageBox.Show("用户名有误,请重新输入用户名！","提示信息");
                        cboUserName.Focus();
                        cboUserName.SelectedIndex = -1;
                        return;
                        }
                        else
                        {
                            MessageBox.Show("密码有误,请重新输入密码！","提示信息");
                            txtPassword.Focus();
                            txtPassword.Clear();
                            return;

                        }
                }
        }
        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("你真的不登录系统吗?", "退出系统提示信息",
        MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        public frmUserLogin()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

  

  
    }
    }

