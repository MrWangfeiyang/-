﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmPublisherManage : Form
    {
       

        BookApp.publisherClass objPublisher = new BookApp.publisherClass();
        int currentLine;
        string[] arrayPublisherId;
        DataTable dt = new DataTable();


        private void publisherInfoManage_Load(object sender, EventArgs e)
        {
            initializeData();
        }

        private void initializeData()
        {
            dt = objPublisher.getPublisherInfo();
            if (dt.Rows.Count != 0)
            {
                dgPublisherInfo.DataSource = dt;
                currentLine = 0;
                setDataGridFormat(dt);
                //currentLine=(int)dgPublisherInfo.CurrentCell.RowIndex;
                txtPublisherName.Text = dgPublisherInfo.Rows[currentLine]
                                        .Cells[1].Value.ToString();
                txtISBN.Text = dgPublisherInfo.Rows[currentLine]
                                        .Cells[2].Value.ToString();
                txtShortName.Text = dgPublisherInfo.Rows[currentLine]
                                        .Cells[3].Value.ToString();
                txtAddress.Text = dgPublisherInfo.Rows[currentLine]
                                        .Cells[4].Value.ToString();
                arrayPublisherId = new string[dt.Rows.Count];
            }
        }

        private void setDataGridFormat(DataTable dt)
        {
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Alignment = System.Windows.Forms
                              .DataGridViewContentAlignment.MiddleCenter;
            this.dgPublisherInfo.ColumnHeadersDefaultCellStyle = headerStyle;
            this.dgPublisherInfo.RowsDefaultCellStyle.BackColor = Color.Bisque;
            this.dgPublisherInfo.AlternatingRowsDefaultCellStyle.BackColor
                                                          = Color.Beige;
            this.dgPublisherInfo.Columns[0].Width = 0;
            this.dgPublisherInfo.Columns[0].Visible = false;
            this.dgPublisherInfo.Columns[1].Width = 130;
            this.dgPublisherInfo.Columns[2].Width = 60;
            this.dgPublisherInfo.Columns[3].Width = 100;
            this.dgPublisherInfo.Columns[4].Width = 150;
            this.dgPublisherInfo.Columns[1].HeaderText = dt.Columns[1].ColumnName;
            this.dgPublisherInfo.Columns[2].HeaderText = dt.Columns[2].ColumnName;
            this.dgPublisherInfo.Columns[3].HeaderText = dt.Columns[3].ColumnName;
            this.dgPublisherInfo.Columns[4].HeaderText = dt.Columns[4].ColumnName;
        }

        private void dgPulisherInfo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(dgPublisherInfo.Rows[currentLine]
                                             .Cells[1].Value.ToString()))
            {
                if (currentLine != dgPublisherInfo.CurrentRow.Index)
                {
                    currentLine = dgPublisherInfo.CurrentRow.Index;
                    txtPublisherName.Text = (object.ReferenceEquals(dgPublisherInfo
                       .Rows[currentLine].Cells[1].Value.ToString(), DBNull.Value)
                           ? "" : dgPublisherInfo.Rows[currentLine]
                                       .Cells[1].Value.ToString());
                    txtISBN.Text = (object.ReferenceEquals(dgPublisherInfo
                       .Rows[currentLine].Cells[2].Value.ToString(), DBNull.Value)
                           ? "" : dgPublisherInfo.Rows[currentLine]
                                       .Cells[2].Value.ToString());
                    txtShortName.Text = (object.ReferenceEquals(dgPublisherInfo
                       .Rows[currentLine].Cells[3].Value.ToString(), DBNull.Value)
                           ? "" : dgPublisherInfo.Rows[currentLine]
                                       .Cells[3].Value.ToString());
                    txtAddress.Text = (object.ReferenceEquals(dgPublisherInfo
                       .Rows[currentLine].Cells[4].Value.ToString(), DBNull.Value)
                           ? "" : dgPublisherInfo.Rows[currentLine]
                                       .Cells[4].Value.ToString());
                }
            }
        }


        private bool getArrPublisherId(DataTable dt)
        {
            int i = 0;
            if ((dt != null))
            {
                string[] arrPublisherId = new string[dt.Rows.Count];
                arrayPublisherId = new string[dt.Rows.Count];
                for (i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    if (!object.ReferenceEquals(dt.Rows[i][0], DBNull.Value))
                    {
                        arrPublisherId[i] = dt.Rows[i][0].ToString();
                    }
                }
                arrayPublisherId = arrPublisherId;
                return true;
            }
            else
            {
                arrayPublisherId = null;
                return false;
            }
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            int i = 0;
            int j = 0;
            if (!getArrPublisherId(dt))
                return;
            //如果已存在,则更新其数量,否则的话插入新记录
            try
            {
                if (dt.Rows.Count != 0)
                {
                    for (i = 0; i <= dt.Rows.Count - 1; i++)
                    {
                        if (dt.Rows[i].RowState == DataRowState.Modified)
                        {
                            for (j = 0; j <= arrayPublisherId.Length - 1; j++)
                            {
                                if ((!object.ReferenceEquals(dt.Rows[i][0].ToString(),
                                                            DBNull.Value)))
                                {
                                    if (dt.Rows[i][0].ToString() == arrayPublisherId[j])
                                    {
                                        objPublisher.publisherInfoEdit(
                                                             dt.Rows[i][0].ToString(),
                                                             dt.Rows[i][1].ToString(),
                                                             dt.Rows[i][2].ToString(),
                                                             dt.Rows[i][3].ToString(),
                                                             dt.Rows[i][4].ToString());
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (dt.Rows[i].RowState == DataRowState.Added)
                            {
                                objPublisher.publisherInfoAdd(
                                                dt.Rows[i][1].ToString(),
                                                dt.Rows[i][2].ToString(),
                                                dt.Rows[i][3].ToString(),
                                                dt.Rows[i][4].ToString());
                            }
                        }
                    }
                }
                MessageBox.Show("成功更新出版社数据表", "提示信息");
                initializeData();

            }
            catch (Exception es)
            {
                MessageBox.Show("更新出版社数据表时出现了错误,错误信息为: " +
                                 es.Message, "提示信息");
            }
        }

        private void txtPublisherName_TextChanged(object sender, EventArgs e)
        {
            dgPublisherInfo.Rows[currentLine].Cells[1].Value = txtPublisherName.Text.Trim();
        }

        private void txtISBN_TextChanged(object sender, EventArgs e)
        {
            dgPublisherInfo.Rows[currentLine].Cells[2].Value = txtISBN.Text.Trim();
        }

        private void txtShortName_TextChanged(object sender, EventArgs e)
        {
            dgPublisherInfo.Rows[currentLine].Cells[3].Value = txtShortName.Text.Trim();
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {
            dgPublisherInfo.Rows[currentLine].Cells[4].Value = txtAddress.Text.Trim();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (objPublisher.publisherInfoDelete(dgPublisherInfo.Rows[dgPublisherInfo
                                              .CurrentRow.Index].Cells[0].Value.ToString()))
            {
                MessageBox.Show("成功删除一条记录", "提示信息"); initializeData();
            }
            else
            {
                MessageBox.Show("删除记录失败", "提示信息");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            initializeData();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public frmPublisherManage()
        {
            InitializeComponent();
        }

       
    }
}