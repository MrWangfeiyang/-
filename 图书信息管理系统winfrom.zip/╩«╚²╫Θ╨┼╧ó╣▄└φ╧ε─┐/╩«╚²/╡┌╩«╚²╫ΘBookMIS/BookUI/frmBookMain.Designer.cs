﻿namespace BookUI
{
    partial class frmBookMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBookMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUser = new System.Windows.Forms.ToolStripMenuItem();
            this.用户权限管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.更改用户密码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.基础数据管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPublisher = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBookType = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBibliothecaInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.馆藏地点管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.借阅者类型管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅者信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.部门信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.书目管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.编制图书条码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图书入库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBookLoan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBookReLoan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBookReturn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.办理借书证ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.数据查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.书目信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅者信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.借阅信息查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.超期图书查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ckcd = new System.Windows.Forms.ToolStripMenuItem();
            this.ckpp = new System.Windows.Forms.ToolStripMenuItem();
            this.czpp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuCloseAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbBookLoan = new System.Windows.Forms.ToolStripButton();
            this.tsbBookReturn = new System.Windows.Forms.ToolStripButton();
            this.tsbBookReLoan = new System.Windows.Forms.ToolStripButton();
            this.tsbHide = new System.Windows.Forms.ToolStripButton();
            this.tsbExit = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.基础数据管理ToolStripMenuItem,
            this.书目管理ToolStripMenuItem,
            this.借阅管理ToolStripMenuItem,
            this.数据查询ToolStripMenuItem,
            this.窗口ToolStripMenuItem,
            this.mnuHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1125, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuReLogin,
            this.mnuUser,
            this.用户权限管理ToolStripMenuItem,
            this.更改用户密码ToolStripMenuItem,
            this.toolStripSeparator1,
            this.mnuExit});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.toolStripMenuItem1.Text = "用户管理";
            // 
            // mnuReLogin
            // 
            this.mnuReLogin.Name = "mnuReLogin";
            this.mnuReLogin.Size = new System.Drawing.Size(148, 22);
            this.mnuReLogin.Text = "用户重新登录";
            this.mnuReLogin.Click += new System.EventHandler(this.mnuReLogin_Click);
            // 
            // mnuUser
            // 
            this.mnuUser.Name = "mnuUser";
            this.mnuUser.Size = new System.Drawing.Size(148, 22);
            this.mnuUser.Text = "用户信息管理";
            this.mnuUser.Click += new System.EventHandler(this.mnuUser_Click);
            // 
            // 用户权限管理ToolStripMenuItem
            // 
            this.用户权限管理ToolStripMenuItem.Name = "用户权限管理ToolStripMenuItem";
            this.用户权限管理ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.用户权限管理ToolStripMenuItem.Text = "用户权限管理";
            // 
            // 更改用户密码ToolStripMenuItem
            // 
            this.更改用户密码ToolStripMenuItem.Name = "更改用户密码ToolStripMenuItem";
            this.更改用户密码ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.更改用户密码ToolStripMenuItem.Text = "更改用户密码";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(145, 6);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(148, 22);
            this.mnuExit.Text = "退出";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // 基础数据管理ToolStripMenuItem
            // 
            this.基础数据管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPublisher,
            this.mnuBookType,
            this.mnuBibliothecaInfo,
            this.馆藏地点管理ToolStripMenuItem,
            this.toolStripSeparator2,
            this.借阅者类型管理ToolStripMenuItem,
            this.借阅者信息管理ToolStripMenuItem,
            this.部门信息管理ToolStripMenuItem});
            this.基础数据管理ToolStripMenuItem.Name = "基础数据管理ToolStripMenuItem";
            this.基础数据管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.基础数据管理ToolStripMenuItem.Text = "基础数据管理";
            // 
            // mnuPublisher
            // 
            this.mnuPublisher.Name = "mnuPublisher";
            this.mnuPublisher.Size = new System.Drawing.Size(160, 22);
            this.mnuPublisher.Text = "出版社信息管理";
            this.mnuPublisher.Click += new System.EventHandler(this.mnuPublisher_Click);
            // 
            // mnuBookType
            // 
            this.mnuBookType.Name = "mnuBookType";
            this.mnuBookType.Size = new System.Drawing.Size(160, 22);
            this.mnuBookType.Text = "图书类型管理";
            this.mnuBookType.Click += new System.EventHandler(this.mnuBookType_Click);
            // 
            // mnuBibliothecaInfo
            // 
            this.mnuBibliothecaInfo.Name = "mnuBibliothecaInfo";
            this.mnuBibliothecaInfo.Size = new System.Drawing.Size(160, 22);
            this.mnuBibliothecaInfo.Text = "书目数据管理";
            this.mnuBibliothecaInfo.Click += new System.EventHandler(this.mnuBibliothecaInfo_Click);
            // 
            // 馆藏地点管理ToolStripMenuItem
            // 
            this.馆藏地点管理ToolStripMenuItem.Name = "馆藏地点管理ToolStripMenuItem";
            this.馆藏地点管理ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.馆藏地点管理ToolStripMenuItem.Text = "馆藏地点管理";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(157, 6);
            // 
            // 借阅者类型管理ToolStripMenuItem
            // 
            this.借阅者类型管理ToolStripMenuItem.Name = "借阅者类型管理ToolStripMenuItem";
            this.借阅者类型管理ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.借阅者类型管理ToolStripMenuItem.Text = "借阅者类型管理";
            // 
            // 借阅者信息管理ToolStripMenuItem
            // 
            this.借阅者信息管理ToolStripMenuItem.Name = "借阅者信息管理ToolStripMenuItem";
            this.借阅者信息管理ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.借阅者信息管理ToolStripMenuItem.Text = "借阅者信息管理";
            // 
            // 部门信息管理ToolStripMenuItem
            // 
            this.部门信息管理ToolStripMenuItem.Name = "部门信息管理ToolStripMenuItem";
            this.部门信息管理ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.部门信息管理ToolStripMenuItem.Text = "部门信息管理";
            // 
            // 书目管理ToolStripMenuItem
            // 
            this.书目管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.编制图书条码ToolStripMenuItem,
            this.图书入库ToolStripMenuItem});
            this.书目管理ToolStripMenuItem.Name = "书目管理ToolStripMenuItem";
            this.书目管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.书目管理ToolStripMenuItem.Text = "书目管理";
            // 
            // 编制图书条码ToolStripMenuItem
            // 
            this.编制图书条码ToolStripMenuItem.Name = "编制图书条码ToolStripMenuItem";
            this.编制图书条码ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.编制图书条码ToolStripMenuItem.Text = "编制图书条码";
            // 
            // 图书入库ToolStripMenuItem
            // 
            this.图书入库ToolStripMenuItem.Name = "图书入库ToolStripMenuItem";
            this.图书入库ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.图书入库ToolStripMenuItem.Text = "图书入库";
            // 
            // 借阅管理ToolStripMenuItem
            // 
            this.借阅管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBookLoan,
            this.mnuBookReLoan,
            this.mnuBookReturn,
            this.toolStripSeparator3,
            this.办理借书证ToolStripMenuItem});
            this.借阅管理ToolStripMenuItem.Name = "借阅管理ToolStripMenuItem";
            this.借阅管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.借阅管理ToolStripMenuItem.Text = "借阅管理";
            // 
            // mnuBookLoan
            // 
            this.mnuBookLoan.Name = "mnuBookLoan";
            this.mnuBookLoan.Size = new System.Drawing.Size(136, 22);
            this.mnuBookLoan.Text = "图书借阅";
            this.mnuBookLoan.Click += new System.EventHandler(this.mnuBookLoan_Click);
            // 
            // mnuBookReLoan
            // 
            this.mnuBookReLoan.Name = "mnuBookReLoan";
            this.mnuBookReLoan.Size = new System.Drawing.Size(136, 22);
            this.mnuBookReLoan.Text = "图书续借";
            this.mnuBookReLoan.Click += new System.EventHandler(this.mnuBookReLoan_Click);
            // 
            // mnuBookReturn
            // 
            this.mnuBookReturn.Name = "mnuBookReturn";
            this.mnuBookReturn.Size = new System.Drawing.Size(136, 22);
            this.mnuBookReturn.Text = "图书归还";
            this.mnuBookReturn.Click += new System.EventHandler(this.mnuBookReturn_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(133, 6);
            // 
            // 办理借书证ToolStripMenuItem
            // 
            this.办理借书证ToolStripMenuItem.Name = "办理借书证ToolStripMenuItem";
            this.办理借书证ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.办理借书证ToolStripMenuItem.Text = "办理借书证";
            // 
            // 数据查询ToolStripMenuItem
            // 
            this.数据查询ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.书目信息查询ToolStripMenuItem,
            this.借阅者信息查询ToolStripMenuItem,
            this.借阅信息查询ToolStripMenuItem,
            this.超期图书查询ToolStripMenuItem});
            this.数据查询ToolStripMenuItem.Name = "数据查询ToolStripMenuItem";
            this.数据查询ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.数据查询ToolStripMenuItem.Text = "数据查询";
            // 
            // 书目信息查询ToolStripMenuItem
            // 
            this.书目信息查询ToolStripMenuItem.Name = "书目信息查询ToolStripMenuItem";
            this.书目信息查询ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.书目信息查询ToolStripMenuItem.Text = "书目信息查询";
            this.书目信息查询ToolStripMenuItem.Click += new System.EventHandler(this.mnuBibliothecaInfo_Click);
            // 
            // 借阅者信息查询ToolStripMenuItem
            // 
            this.借阅者信息查询ToolStripMenuItem.Name = "借阅者信息查询ToolStripMenuItem";
            this.借阅者信息查询ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.借阅者信息查询ToolStripMenuItem.Text = "借阅者信息查询";
            // 
            // 借阅信息查询ToolStripMenuItem
            // 
            this.借阅信息查询ToolStripMenuItem.Name = "借阅信息查询ToolStripMenuItem";
            this.借阅信息查询ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.借阅信息查询ToolStripMenuItem.Text = "借阅信息查询";
            // 
            // 超期图书查询ToolStripMenuItem
            // 
            this.超期图书查询ToolStripMenuItem.Name = "超期图书查询ToolStripMenuItem";
            this.超期图书查询ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.超期图书查询ToolStripMenuItem.Text = "超期图书查询";
            // 
            // 窗口ToolStripMenuItem
            // 
            this.窗口ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ckcd,
            this.ckpp,
            this.czpp,
            this.toolStripSeparator4,
            this.mnuCloseAll});
            this.窗口ToolStripMenuItem.Name = "窗口ToolStripMenuItem";
            this.窗口ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.窗口ToolStripMenuItem.Text = "窗口";
            // 
            // ckcd
            // 
            this.ckcd.Name = "ckcd";
            this.ckcd.Size = new System.Drawing.Size(124, 22);
            this.ckcd.Text = "窗口层叠";
            this.ckcd.Click += new System.EventHandler(this.ckcd_Click);
            // 
            // ckpp
            // 
            this.ckpp.Name = "ckpp";
            this.ckpp.Size = new System.Drawing.Size(124, 22);
            this.ckpp.Text = "窗口平铺";
            this.ckpp.Click += new System.EventHandler(this.ckpp_Click);
            // 
            // czpp
            // 
            this.czpp.Name = "czpp";
            this.czpp.Size = new System.Drawing.Size(124, 22);
            this.czpp.Text = "垂直平铺";
            this.czpp.Click += new System.EventHandler(this.czpp_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(121, 6);
            // 
            // mnuCloseAll
            // 
            this.mnuCloseAll.Name = "mnuCloseAll";
            this.mnuCloseAll.Size = new System.Drawing.Size(124, 22);
            this.mnuCloseAll.Text = "全部关闭";
            this.mnuCloseAll.Click += new System.EventHandler(this.mnuCloseAll_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAbout,
            this.帮助ToolStripMenuItem1});
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(44, 21);
            this.mnuHelp.Text = "帮助";
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(100, 22);
            this.mnuAbout.Text = "关于";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // 帮助ToolStripMenuItem1
            // 
            this.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            this.帮助ToolStripMenuItem1.Size = new System.Drawing.Size(100, 22);
            this.帮助ToolStripMenuItem1.Text = "帮助";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbBookLoan,
            this.tsbBookReturn,
            this.tsbBookReLoan,
            this.tsbHide,
            this.tsbExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1125, 48);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbBookLoan
            // 
            this.tsbBookLoan.Image = ((System.Drawing.Image)(resources.GetObject("tsbBookLoan.Image")));
            this.tsbBookLoan.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBookLoan.Name = "tsbBookLoan";
            this.tsbBookLoan.Size = new System.Drawing.Size(60, 45);
            this.tsbBookLoan.Text = "图书借阅";
            this.tsbBookLoan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbBookLoan.Click += new System.EventHandler(this.tsbBookLoan_Click);
            // 
            // tsbBookReturn
            // 
            this.tsbBookReturn.Image = ((System.Drawing.Image)(resources.GetObject("tsbBookReturn.Image")));
            this.tsbBookReturn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBookReturn.Name = "tsbBookReturn";
            this.tsbBookReturn.Size = new System.Drawing.Size(60, 45);
            this.tsbBookReturn.Text = "图书归还";
            this.tsbBookReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbBookReturn.Click += new System.EventHandler(this.tsbBookReturn_Click);
            // 
            // tsbBookReLoan
            // 
            this.tsbBookReLoan.Image = ((System.Drawing.Image)(resources.GetObject("tsbBookReLoan.Image")));
            this.tsbBookReLoan.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbBookReLoan.Name = "tsbBookReLoan";
            this.tsbBookReLoan.Size = new System.Drawing.Size(60, 45);
            this.tsbBookReLoan.Text = "图书续借";
            this.tsbBookReLoan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbBookReLoan.Click += new System.EventHandler(this.tsbBookReLoan_Click);
            // 
            // tsbHide
            // 
            this.tsbHide.Image = ((System.Drawing.Image)(resources.GetObject("tsbHide.Image")));
            this.tsbHide.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbHide.Name = "tsbHide";
            this.tsbHide.Size = new System.Drawing.Size(72, 45);
            this.tsbHide.Text = "隐藏导航栏";
            this.tsbHide.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbHide.Click += new System.EventHandler(this.tsbHide_Click);
            // 
            // tsbExit
            // 
            this.tsbExit.Image = ((System.Drawing.Image)(resources.GetObject("tsbExit.Image")));
            this.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExit.Name = "tsbExit";
            this.tsbExit.Size = new System.Drawing.Size(60, 45);
            this.tsbExit.Text = "系统退出";
            this.tsbExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbExit.Click += new System.EventHandler(this.tsbExit_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 542);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1125, 28);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.AutoSize = false;
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(140, 23);
            this.toolStripStatusLabel1.Text = "欢迎您使用图书管理系统";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.AutoSize = false;
            this.toolStripStatusLabel2.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(280, 23);
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(690, 23);
            this.toolStripStatusLabel3.Spring = true;
            // 
            // frmBookMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1125, 570);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmBookMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "图书管理系统";
            this.TransparencyKey = System.Drawing.Color.White;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmBookMain_Load);
            this.MdiChildActivate += new System.EventHandler(this.frmBookMain_MdiChildActivate);
            this.Click += new System.EventHandler(this.mnuReLogin_Click);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton tsbBookLoan;
        private System.Windows.Forms.ToolStripButton tsbBookReturn;
        private System.Windows.Forms.ToolStripMenuItem mnuReLogin;
        private System.Windows.Forms.ToolStripMenuItem mnuUser;
        private System.Windows.Forms.ToolStripMenuItem 用户权限管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 更改用户密码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基础数据管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuPublisher;
        private System.Windows.Forms.ToolStripMenuItem mnuBookType;
        private System.Windows.Forms.ToolStripMenuItem mnuBibliothecaInfo;
        private System.Windows.Forms.ToolStripMenuItem 馆藏地点管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsbBookReLoan;
        private System.Windows.Forms.ToolStripButton tsbHide;
        private System.Windows.Forms.ToolStripButton tsbExit;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 借阅者类型管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅者信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 部门信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 书目管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 编制图书条码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 图书入库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuBookLoan;
        private System.Windows.Forms.ToolStripMenuItem mnuBookReLoan;
        private System.Windows.Forms.ToolStripMenuItem mnuBookReturn;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 办理借书证ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 书目信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅者信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 借阅信息查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 超期图书查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ckcd;
        private System.Windows.Forms.ToolStripMenuItem ckpp;
        private System.Windows.Forms.ToolStripMenuItem czpp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem mnuCloseAll;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem1;
    }
}