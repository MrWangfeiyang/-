﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmBookReturnOrRenew : Form
    {
        public frmBookReturnOrRenew()
        {
            InitializeComponent();
        }
        public frmBookReturnOrRenew(string flag)
        {
            InitializeComponent();
            flagBorrow = flag;
        }

        public string flagBorrow = "";
        BookApp.returnOrRenewClass objReturnOrRenew = new BookApp.returnOrRenewClass();
        BookApp.loanClass loanObj = new BookApp.loanClass();
        string borrowerId;
        string bookBarcode;
        string bibliothecaId;
        
        private void getBorroweLoanInfo()
        {
            if(loanObj.isOverdue(borrowerId)==true)
            {
                DataTable dt = new DataTable();
                dt=loanObj.getLoanInfo(borrowerId);
                    if(dt.Rows.Count !=0)
                {
                    dgLoanInfo.DataSource=dt;
                    btnGetBookBarcode.Enabled=false;

                }
                else
                {
                    dgLoanInfo.DataSource=null;
                    dgLoanInfo.Refresh();
                }
            }
            else
            {
                MessageBox.Show("你已经有超期图书了,请归还再借! ",
                    "提示信息",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
        
        private void getBook()
        {
            DataTable dt = new DataTable();
            dt = loanObj.getBookInfo(bookBarcode);
            if(dt.Rows.Count !=0)
            {
                txtBookName.Text=dt.Rows[0]["图书名称"].ToString();
                txtPublisher.Text = dt.Rows[0]["出版社名称"].ToString();
                txtAuthor.Text = dt.Rows[0]["作者"].ToString();
                txtAuthor.Text = dt.Rows[0]["书目编号"].ToString();
            }
        }
        
        private void clearControl()
        {
            txtBookBarcode.Text = "";
            txtBookName.Text = "";
            txtPublisher.Text = "";
            txtAuthor.Text = "";

        }
        


        

        private void frmBookReturnOrRenew_Load(object sender, EventArgs e)
        {
            if(flagBorrow=="return")
            {
                this.Text = "归还图书";
                btnBookRenew.Enabled = false;
                btnBookRenew.Visible = false;
                btnBookReturn.Enabled = true;
                btnBookReturn.Visible = true;
                groupBox1.Text = "凭证归还";
                groupBox1.Text = "凭书归还";
            }
            else
            {
                this.Text = "续借图书";
                btnBookRenew.Enabled = true;
                btnBookReturn.Enabled = false;
                btnBookRenew.Visible = true;
                btnBookReturn.Visible = false;
                groupBox1.Text = "凭证续借";
                groupBox1.Text = "凭书续借";
            }
            txtBookName.Enabled = false;
            txtPublisher.Enabled = false;
            txtAuthor.Enabled = false;
            txtBorrowerId.Focus();
            DataGridViewCellStyle headerStyle = new DataGridViewCellStyle();
            headerStyle.Alignment =
                System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgLoanInfo.ColumnHeadersDefaultCellStyle = headerStyle;
        }

       private void btnGetBorrowerId_Click(object sender, EventArgs e)
        {

            DataTable dt = new DataTable();
            frmSelectLoanBook frmLoanBook = default(frmSelectLoanBook);
            Point startLocation = default(Point);
            startLocation.X = this.Location.X + txtBorrowerId.Location.X;
            startLocation.Y = this.Location.Y + txtBookBarcode.Location.Y + 50;
            frmLoanBook = new frmSelectLoanBook(startLocation);
            frmLoanBook.ShowDialog();
            bookBarcode = frmLoanBook.getLoanBookId();
            txtBookBarcode.Text = bookBarcode;
            getBook();
            dt = objReturnOrRenew.getLoanInfoByBarcode(bookBarcode);
            txtBorrowerId.Text = dt.Rows[0][1].ToString();
            dgLoanInfo.DataSource = dt;
            btnGetBorrowerId.Enabled = false;
            txtBorrowerId.Enabled = false;
             
        }
       

        private void txtBorrowerId_KeyDown(object sender, KeyEventArgs e)
        {
          if(e.KeyCode==Keys.Enter)
          {
              if(txtBorrowerId.Text.Trim().Length>=5)
              {
                  borrowerId = txtBorrowerId.Text.Trim();
                  getBorroweLoanInfo();
              }
          }
        }

        private void btnGetBookBarcode_Click(object sender, EventArgs e)
        {
            DataTable dt= new DataTable();
            frmSelectLoanBook frmLoanBook= default(frmSelectLoanBook);
            Point startLocation = default(Point);
            startLocation.X = this.Location.X + txtBorrowerId.Location.X;
            startLocation.Y = this.Location.Y + txtBookBarcode.Location.Y + 50;
            frmLoanBook = new frmSelectLoanBook(startLocation);
            frmLoanBook.ShowDialog();
            bookBarcode = frmLoanBook.getLoanBookId();
            txtBookBarcode.Text = bookBarcode;
            getBook();
            dt = objReturnOrRenew.getLoanInfoByBarcode(bookBarcode);
            txtBorrowerId.Text = dt.Rows[0][1].ToString();
            dgLoanInfo.DataSource = dt;
            btnGetBorrowerId.Enabled = false;
            txtBorrowerId.Enabled = false;

        }


        private void txtBookBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                bookBarcode = txtBookBarcode.Text.Trim();
                getBook();
                //btnGetBookbarcode按钮可用时
                if(btnGetBookBarcode.Enabled==true)
                {
                    DataTable dt = new DataTable();
                    dt = objReturnOrRenew.getLoanInfoByBarcode(bookBarcode);
                    txtBorrowerId.Text = dt.Rows[0][1].ToString();
                    dgLoanInfo.DataSource = dt;
                    btnGetBorrowerId.Enabled = false;
                    txtBorrowerId.Enabled = false;
                }
            }
        }

        private void dgLoanInfo_DoubleClick(object sender, EventArgs e)
        {
            bookBarcode = dgLoanInfo.Rows[dgLoanInfo.CurrentRow.Index].Cells[2].Value.ToString();
            txtBookBarcode.Text = bookBarcode;
            getBook();
        }



        private bool checkEmpty()
        {
            if (txtBookBarcode.Text.Trim().Length == 0)
            {
                MessageBox.Show("图书条码不能为空,请输入图形条码!", "提示信息");
                txtBookBarcode.Focus();
                return false;
            }
            if (txtBorrowerId.Text.Trim().Length == 0)
            {
                MessageBox.Show("借阅者编号不能为空,请输入借阅者编号!", "提示信息");
                txtBorrowerId.Focus();
                return false;

            }
            if (txtBookName.Text.Trim().Length == 0)
            {
                MessageBox.Show("图书名称不能为空,请输入图书名称!", "提示信息");
                txtBookName.Focus();
                return false;
            }
            if (txtPublisher.Text.Trim().Length == 0)
            {
                MessageBox.Show("出版社不能为空,请输入出版社!", "提示信息");
                txtPublisher.Focus();
                return false;

            }
            if (txtAuthor.Text.Trim().Length == 0)
            {
                MessageBox.Show("作者不能为空,请输入作者!", "提示信息");
                txtAuthor.Focus();
                return false;

            }
            return true;
        }






        private void btnBookRenew_Click(object sender, EventArgs e)
        {
            string strCardState=null;
            int maxDay = 0;
            //存放限借期限
            DataTable dt = new DataTable();
            if(checkEmpty()==false)
            {
                return;
            }
            //判断读者是否有超期图书
            dt = loanObj.getBorrowerInfo(borrowerId);
            maxDay = Convert.ToInt32(dt.Rows[0]["最长借书期限"]);
            strCardState = dt.Rows[0]["借书证状态"].ToString();
            switch(strCardState)
            {
                //判断借书证状态
                case "有效":
                    if(objReturnOrRenew.loanRenew(maxDay,borrowerId,bookBarcode)==true)
                    {
                        dgLoanInfo.DataSource = null;
                        dgLoanInfo.DataSource = loanObj.getLoanInfo(borrowerId);
                        dgLoanInfo.Refresh();
                        MessageBox.Show("图书续借成功! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("图书借阅失败! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Question);
                        return;
                    }
                    break;
                case"挂失":
                    MessageBox.Show("读者的借书证已被挂失,不能继续使用! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                case"停用":
                        MessageBox.Show("读者的借书证已被停用，不能继续使用! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
            }
            btnGetBorrowerId.Enabled = true;
        }

        private void btnBookReturn_Click(object sender, EventArgs e)
        {
          if(objReturnOrRenew.loanDelete(borrowerId,bookBarcode)==true)
          {
              loanObj.setBookState(bookBarcode, "在藏");
              //重新设置图书信息表中的图书状态
              objReturnOrRenew.bookNowNumAdd(bibliothecaId);
              //重新设置书目信息表中的现存数量
              dgLoanInfo.DataSource = null;
              dgLoanInfo.DataSource = loanObj.getLoanInfo(borrowerId);
              dgLoanInfo.Refresh();
              clearControl();
              MessageBox.Show("图书归还成功! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Information);
              
          }
          else
          {
              MessageBox.Show("图书归还失败! ", "提示信息", MessageBoxButtons.OK, MessageBoxIcon.Question);
             
          }

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }




        
    }
}
