﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmBookMain : Form
    {
        public frmBookMain()
        {
            InitializeComponent();
        }

        public static string currentUserName = "";

        

        private void frmBookMain_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = "当前登录用户为: " + currentUserName;
            toolStripStatusLabel3.Text = "登录日期为: " + DateTime.Now.ToLongDateString().ToString();

        }
        private bool checkMdiChild(string childFormName)
        {
            foreach (Form childForm in this.MdiChildren)
            {
                if (childForm.Name.Trim() == childFormName.Trim())
                {
                    if (childForm.Visible)
                    {
                        childForm.Activate();
                    }
                    else
                    {
                        childForm.Show();
                    }
                    return true;
                }
            }
            return false;

        }
        private void frmBookMain_MdiChildActivate(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild != null))
            {
                toolStripStatusLabel3.Text = "当前操作的窗口是:" + this.ActiveMdiChild.Text;
            }
            else
            {
                toolStripStatusLabel3.Text = "登陆日期为: " + DateTime.Now.ToLongDateString().ToString();
            }
        }


      
        private void tsbBookLoan_Click(object sender, EventArgs e)
        {
            mnuBookLoan.PerformClick();

        }

        private void tsbBookReturn_Click(object sender, EventArgs e)
        {
            mnuBookReturn.PerformClick();
        }

        private void tsbBookReLoan_Click(object sender, EventArgs e)
        {
            mnuBookReLoan.PerformClick();
        }
        
        private void tsbHide_Click(object sender, EventArgs e)
        {
            if (tsbHide.Text == "隐藏导航栏")
            {
                tsbHide.Text = "显示导航栏";

            }

            else
            {
                tsbHide.Text = "隐藏导航栏";
            }
        }

        private void tsbExit_Click(object sender, EventArgs e)
        {
            


            DialogResult result = MessageBox.Show("您是否真的要退出图书管理系统?",
                                                                 "提示信息",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void mnuBibliothecaInfo_Click(object sender, EventArgs e)
        {
            if (checkMdiChild("frmBibliothecaInfoManage"))
            {
                return;
            }
      
            frmBibliothecaInfoManage bibliothecaInfoManage =
                new frmBibliothecaInfoManage();
            bibliothecaInfoManage.MdiParent = this;
            bibliothecaInfoManage.WindowState = FormWindowState.Normal;
            //设置子窗体的位置是手动的,否则会靠左上角出现
            bibliothecaInfoManage.StartPosition = FormStartPosition.Manual;
            bibliothecaInfoManage.Location = new Point(5, 5);
            bibliothecaInfoManage.Show();
            bibliothecaInfoManage.TopMost = true;
        }
        private void mnuReLogin_Click(object sender, EventArgs e)
        {
            frmUserLogin frmUL = new frmUserLogin();//新建Login窗口
            frmUL.ShowDialog(); //使用模式对话框方法显示frmUserLogin
            if (frmUL.DialogResult == DialogResult.OK)//判断是否登录成功
            {
                frmUL.Close();
                toolStripStatusLabel2.Text = "当前登录用户为: " + currentUserName;
                toolStripStatusLabel3.Text = "登录日期为: " +
                    DateTime.Now.ToLongDateString().ToString();
            }
        }
        private void mnuBookReturn_Click(object sender, EventArgs e)
        {

            if (checkMdiChild("frmBookReturnOrRenew"))
            {
                return;
            }
            frmBookReturnOrRenew bookReturnOrRenew = new frmBookReturnOrRenew("return");
            bookReturnOrRenew.MdiParent = this;
            bookReturnOrRenew.WindowState = FormWindowState.Normal;
            bookReturnOrRenew.StartPosition = FormStartPosition.Manual;
            bookReturnOrRenew.Location = new Point(5, 5);
            bookReturnOrRenew.Show();
            bookReturnOrRenew.TopMost = true;
            //bookReturnOrRenew.flagBorrow = "return";

        }
        private void mnuBookLoan_Click(object sender, EventArgs e)
        {
           
    
            
            if (checkMdiChild("frmBookLoanManage"))
            {
                return;
            }
            frmBookLoanManage bookLoanManage = new frmBookLoanManage();
            bookLoanManage.MdiParent = this;
            bookLoanManage.WindowState = FormWindowState.Normal;
            bookLoanManage.StartPosition = FormStartPosition.Manual;
            bookLoanManage.Location = new Point(5, 5);
            bookLoanManage.Show();
            bookLoanManage.TopMost = true;
        }
        private void mnuSystemHelp_Click(object sender, EventArgs e)
        {
            string file = null;
            file = Application.StartupPath + "/help.chm";
            Help.ShowHelp(this, file);
        }
        private void mnuExit_Click(object sender,EventArgs e)
        {
            DialogResult result=MessageBox.Show("您是否真的要退出图书管理系统?",
                                                                 "提示信息",
                MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if(result==DialogResult.Yes)
            {
                Application.Exit();
            }
        }
  private void ckcd_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

       

        private void ckpp_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void czpp_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

  
 private void mnuCloseAll_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in this.MdiChildren)
            {
                childForm.Close();
            }
        }

 private void mnuAbout_Click(object sender, EventArgs e)
 {
     if (checkMdiChild("AboutBox1"))
     {
         return;
     }
    
     AboutBox1 AboutBox1 = new AboutBox1();
     AboutBox1.MdiParent = this;
     AboutBox1.WindowState = FormWindowState.Normal;
     AboutBox1.StartPosition = FormStartPosition.Manual;
     AboutBox1.Location = new Point(5, 5);
     AboutBox1.Show();
     AboutBox1.TopMost = true;
 }

 private void mnuUser_Click(object sender, EventArgs e)
 {
     if (checkMdiChild("frmUserManage"))
     {
         return;
     }

     frmUserManage frmUserManage = new frmUserManage();
     frmUserManage.MdiParent = this;
     frmUserManage.WindowState = FormWindowState.Normal;
     frmUserManage.StartPosition = FormStartPosition.Manual;
     frmUserManage.Location = new Point(5, 5);
     frmUserManage.Show();
     frmUserManage.TopMost = true;
 }

 private void mnuPublisher_Click(object sender, EventArgs e)
 {
     if (checkMdiChild("frmPublisherManage"))
     {
         return;
     }

     frmPublisherManage publisherInfoManage = new frmPublisherManage();
     publisherInfoManage.MdiParent = this;
     publisherInfoManage.WindowState = FormWindowState.Normal;
     publisherInfoManage.StartPosition = FormStartPosition.Manual;
     publisherInfoManage.Location = new Point(5, 5);
     publisherInfoManage.Show();
     publisherInfoManage.TopMost = true;

 }

 private void mnuBookType_Click(object sender, EventArgs e)
 {
     if (checkMdiChild("frmBookTypeManage"))
     {
         return;
     }

     frmBookTypeManage frmBookTypeManage = new frmBookTypeManage();
     frmBookTypeManage.MdiParent = this;
     frmBookTypeManage.WindowState = FormWindowState.Normal;
     frmBookTypeManage.StartPosition = FormStartPosition.Manual;
     frmBookTypeManage.Location = new Point(5, 5);
     frmBookTypeManage.Show();
     frmBookTypeManage.TopMost = true;
 }

 private void mnuBookReLoan_Click(object sender, EventArgs e)
 {

     if (checkMdiChild("frmBookReturnOrRenew"))
     {
         return;
     }
     frmBookReturnOrRenew bookReturnOrRenew = new frmBookReturnOrRenew("renew");
     bookReturnOrRenew.MdiParent = this;
     bookReturnOrRenew.WindowState = FormWindowState.Normal;
     bookReturnOrRenew.StartPosition = FormStartPosition.Manual;
     bookReturnOrRenew.Location = new Point(5, 5);
     bookReturnOrRenew.Show();
     bookReturnOrRenew.TopMost = true;
    

 }

 
        

    }
}