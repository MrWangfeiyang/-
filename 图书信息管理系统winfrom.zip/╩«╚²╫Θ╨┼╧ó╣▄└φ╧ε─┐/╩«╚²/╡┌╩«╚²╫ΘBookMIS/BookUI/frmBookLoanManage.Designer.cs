﻿namespace BookUI
{
    partial class frmBookLoanManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbBorrowerInfo = new System.Windows.Forms.GroupBox();
            this.txtForegift = new System.Windows.Forms.TextBox();
            this.txtLoanNums = new System.Windows.Forms.TextBox();
            this.txtPermitNums = new System.Windows.Forms.TextBox();
            this.btnSelectBorrowerId = new System.Windows.Forms.Button();
            this.txtCardState = new System.Windows.Forms.TextBox();
            this.txtBorrowerName = new System.Windows.Forms.TextBox();
            this.lblForegift = new System.Windows.Forms.Label();
            this.lblLoan = new System.Windows.Forms.Label();
            this.lblPermitNums = new System.Windows.Forms.Label();
            this.txtBorrowerId = new System.Windows.Forms.TextBox();
            this.lblCardState = new System.Windows.Forms.Label();
            this.lblBorrowerName = new System.Windows.Forms.Label();
            this.lblBorrowerId = new System.Windows.Forms.Label();
            this.dgLoanInfo = new System.Windows.Forms.DataGridView();
            this.gbBookInfo = new System.Windows.Forms.GroupBox();
            this.btnSelectBookBarcode = new System.Windows.Forms.Button();
            this.txtBookBarcode = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtNowNums = new System.Windows.Forms.TextBox();
            this.txtTotalNums = new System.Windows.Forms.TextBox();
            this.txtAuthor = new System.Windows.Forms.TextBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.lblBookBarcode = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblBookName = new System.Windows.Forms.Label();
            this.lblNowNums = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblTotalNums = new System.Windows.Forms.Label();
            this.gbLoanInfo = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnLoan = new System.Windows.Forms.Button();
            this.gbBorrowerInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLoanInfo)).BeginInit();
            this.gbBookInfo.SuspendLayout();
            this.gbLoanInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbBorrowerInfo
            // 
            this.gbBorrowerInfo.Controls.Add(this.txtForegift);
            this.gbBorrowerInfo.Controls.Add(this.txtLoanNums);
            this.gbBorrowerInfo.Controls.Add(this.txtPermitNums);
            this.gbBorrowerInfo.Controls.Add(this.btnSelectBorrowerId);
            this.gbBorrowerInfo.Controls.Add(this.txtCardState);
            this.gbBorrowerInfo.Controls.Add(this.txtBorrowerName);
            this.gbBorrowerInfo.Controls.Add(this.lblForegift);
            this.gbBorrowerInfo.Controls.Add(this.lblLoan);
            this.gbBorrowerInfo.Controls.Add(this.lblPermitNums);
            this.gbBorrowerInfo.Controls.Add(this.txtBorrowerId);
            this.gbBorrowerInfo.Controls.Add(this.lblCardState);
            this.gbBorrowerInfo.Controls.Add(this.lblBorrowerName);
            this.gbBorrowerInfo.Controls.Add(this.lblBorrowerId);
            this.gbBorrowerInfo.Location = new System.Drawing.Point(6, 9);
            this.gbBorrowerInfo.Margin = new System.Windows.Forms.Padding(4);
            this.gbBorrowerInfo.Name = "gbBorrowerInfo";
            this.gbBorrowerInfo.Padding = new System.Windows.Forms.Padding(4);
            this.gbBorrowerInfo.Size = new System.Drawing.Size(309, 346);
            this.gbBorrowerInfo.TabIndex = 0;
            this.gbBorrowerInfo.TabStop = false;
            this.gbBorrowerInfo.Text = "借阅者信息";
            // 
            // txtForegift
            // 
            this.txtForegift.Location = new System.Drawing.Point(110, 300);
            this.txtForegift.Margin = new System.Windows.Forms.Padding(4);
            this.txtForegift.Name = "txtForegift";
            this.txtForegift.Size = new System.Drawing.Size(188, 28);
            this.txtForegift.TabIndex = 12;
            // 
            // txtLoanNums
            // 
            this.txtLoanNums.Location = new System.Drawing.Point(110, 246);
            this.txtLoanNums.Margin = new System.Windows.Forms.Padding(4);
            this.txtLoanNums.Name = "txtLoanNums";
            this.txtLoanNums.Size = new System.Drawing.Size(188, 28);
            this.txtLoanNums.TabIndex = 11;
            // 
            // txtPermitNums
            // 
            this.txtPermitNums.Location = new System.Drawing.Point(110, 192);
            this.txtPermitNums.Margin = new System.Windows.Forms.Padding(4);
            this.txtPermitNums.Name = "txtPermitNums";
            this.txtPermitNums.Size = new System.Drawing.Size(188, 28);
            this.txtPermitNums.TabIndex = 10;
            // 
            // btnSelectBorrowerId
            // 
            this.btnSelectBorrowerId.Location = new System.Drawing.Point(249, 27);
            this.btnSelectBorrowerId.Margin = new System.Windows.Forms.Padding(4);
            this.btnSelectBorrowerId.Name = "btnSelectBorrowerId";
            this.btnSelectBorrowerId.Size = new System.Drawing.Size(50, 32);
            this.btnSelectBorrowerId.TabIndex = 4;
            this.btnSelectBorrowerId.Text = "...";
            this.btnSelectBorrowerId.UseVisualStyleBackColor = true;
            this.btnSelectBorrowerId.Click += new System.EventHandler(this.bthSelectBorrowerId_Click);
            // 
            // txtCardState
            // 
            this.txtCardState.Location = new System.Drawing.Point(110, 138);
            this.txtCardState.Margin = new System.Windows.Forms.Padding(4);
            this.txtCardState.Name = "txtCardState";
            this.txtCardState.Size = new System.Drawing.Size(188, 28);
            this.txtCardState.TabIndex = 9;
            // 
            // txtBorrowerName
            // 
            this.txtBorrowerName.Location = new System.Drawing.Point(110, 84);
            this.txtBorrowerName.Margin = new System.Windows.Forms.Padding(4);
            this.txtBorrowerName.Name = "txtBorrowerName";
            this.txtBorrowerName.Size = new System.Drawing.Size(188, 28);
            this.txtBorrowerName.TabIndex = 8;
            // 
            // lblForegift
            // 
            this.lblForegift.AutoSize = true;
            this.lblForegift.Location = new System.Drawing.Point(6, 304);
            this.lblForegift.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblForegift.Name = "lblForegift";
            this.lblForegift.Size = new System.Drawing.Size(98, 18);
            this.lblForegift.TabIndex = 7;
            this.lblForegift.Text = "押金剩余：";
            // 
            // lblLoan
            // 
            this.lblLoan.AutoSize = true;
            this.lblLoan.Location = new System.Drawing.Point(6, 250);
            this.lblLoan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoan.Name = "lblLoan";
            this.lblLoan.Size = new System.Drawing.Size(89, 18);
            this.lblLoan.TabIndex = 6;
            this.lblLoan.Text = "已借数量:";
            // 
            // lblPermitNums
            // 
            this.lblPermitNums.AutoSize = true;
            this.lblPermitNums.Location = new System.Drawing.Point(6, 196);
            this.lblPermitNums.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPermitNums.Name = "lblPermitNums";
            this.lblPermitNums.Size = new System.Drawing.Size(89, 18);
            this.lblPermitNums.TabIndex = 5;
            this.lblPermitNums.Text = "限借数量:";
            // 
            // txtBorrowerId
            // 
            this.txtBorrowerId.Location = new System.Drawing.Point(110, 27);
            this.txtBorrowerId.Margin = new System.Windows.Forms.Padding(4);
            this.txtBorrowerId.Name = "txtBorrowerId";
            this.txtBorrowerId.Size = new System.Drawing.Size(148, 28);
            this.txtBorrowerId.TabIndex = 3;
            this.txtBorrowerId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBorrowerId_KeyDown);
            // 
            // lblCardState
            // 
            this.lblCardState.AutoSize = true;
            this.lblCardState.Location = new System.Drawing.Point(6, 142);
            this.lblCardState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCardState.Name = "lblCardState";
            this.lblCardState.Size = new System.Drawing.Size(107, 18);
            this.lblCardState.TabIndex = 4;
            this.lblCardState.Text = "借书证状态:";
            // 
            // lblBorrowerName
            // 
            this.lblBorrowerName.AutoSize = true;
            this.lblBorrowerName.Location = new System.Drawing.Point(6, 88);
            this.lblBorrowerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBorrowerName.Name = "lblBorrowerName";
            this.lblBorrowerName.Size = new System.Drawing.Size(53, 18);
            this.lblBorrowerName.TabIndex = 3;
            this.lblBorrowerName.Text = "姓名:";
            // 
            // lblBorrowerId
            // 
            this.lblBorrowerId.AutoSize = true;
            this.lblBorrowerId.Location = new System.Drawing.Point(6, 34);
            this.lblBorrowerId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBorrowerId.Name = "lblBorrowerId";
            this.lblBorrowerId.Size = new System.Drawing.Size(107, 18);
            this.lblBorrowerId.TabIndex = 2;
            this.lblBorrowerId.Text = "借阅者编号:";
            // 
            // dgLoanInfo
            // 
            this.dgLoanInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgLoanInfo.Location = new System.Drawing.Point(9, 24);
            this.dgLoanInfo.Margin = new System.Windows.Forms.Padding(4);
            this.dgLoanInfo.Name = "dgLoanInfo";
            this.dgLoanInfo.RowTemplate.Height = 23;
            this.dgLoanInfo.Size = new System.Drawing.Size(607, 159);
            this.dgLoanInfo.TabIndex = 1;
            // 
            // gbBookInfo
            // 
            this.gbBookInfo.Controls.Add(this.btnSelectBookBarcode);
            this.gbBookInfo.Controls.Add(this.txtBookBarcode);
            this.gbBookInfo.Controls.Add(this.txtPrice);
            this.gbBookInfo.Controls.Add(this.txtNowNums);
            this.gbBookInfo.Controls.Add(this.txtTotalNums);
            this.gbBookInfo.Controls.Add(this.txtAuthor);
            this.gbBookInfo.Controls.Add(this.txtBookName);
            this.gbBookInfo.Controls.Add(this.lblBookBarcode);
            this.gbBookInfo.Controls.Add(this.lblPrice);
            this.gbBookInfo.Controls.Add(this.lblBookName);
            this.gbBookInfo.Controls.Add(this.lblNowNums);
            this.gbBookInfo.Controls.Add(this.lblAuthor);
            this.gbBookInfo.Controls.Add(this.lblTotalNums);
            this.gbBookInfo.Location = new System.Drawing.Point(330, 9);
            this.gbBookInfo.Margin = new System.Windows.Forms.Padding(4);
            this.gbBookInfo.Name = "gbBookInfo";
            this.gbBookInfo.Padding = new System.Windows.Forms.Padding(4);
            this.gbBookInfo.Size = new System.Drawing.Size(292, 346);
            this.gbBookInfo.TabIndex = 1;
            this.gbBookInfo.TabStop = false;
            this.gbBookInfo.Text = "待借图书信息";
            // 
            // btnSelectBookBarcode
            // 
            this.btnSelectBookBarcode.Location = new System.Drawing.Point(232, 28);
            this.btnSelectBookBarcode.Margin = new System.Windows.Forms.Padding(4);
            this.btnSelectBookBarcode.Name = "btnSelectBookBarcode";
            this.btnSelectBookBarcode.Size = new System.Drawing.Size(50, 32);
            this.btnSelectBookBarcode.TabIndex = 13;
            this.btnSelectBookBarcode.Text = "...";
            this.btnSelectBookBarcode.UseVisualStyleBackColor = true;
            this.btnSelectBookBarcode.Click += new System.EventHandler(this.bthSelectBookBarcode_Click);
            // 
            // txtBookBarcode
            // 
            this.txtBookBarcode.Location = new System.Drawing.Point(94, 28);
            this.txtBookBarcode.Margin = new System.Windows.Forms.Padding(4);
            this.txtBookBarcode.Name = "txtBookBarcode";
            this.txtBookBarcode.Size = new System.Drawing.Size(148, 28);
            this.txtBookBarcode.TabIndex = 13;
            this.txtBookBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBookBarcode_KeyDown);
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(94, 298);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(188, 28);
            this.txtPrice.TabIndex = 17;
            // 
            // txtNowNums
            // 
            this.txtNowNums.Location = new System.Drawing.Point(94, 244);
            this.txtNowNums.Margin = new System.Windows.Forms.Padding(4);
            this.txtNowNums.Name = "txtNowNums";
            this.txtNowNums.Size = new System.Drawing.Size(188, 28);
            this.txtNowNums.TabIndex = 16;
            // 
            // txtTotalNums
            // 
            this.txtTotalNums.Location = new System.Drawing.Point(94, 190);
            this.txtTotalNums.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalNums.Name = "txtTotalNums";
            this.txtTotalNums.Size = new System.Drawing.Size(188, 28);
            this.txtTotalNums.TabIndex = 15;
            // 
            // txtAuthor
            // 
            this.txtAuthor.Location = new System.Drawing.Point(94, 136);
            this.txtAuthor.Margin = new System.Windows.Forms.Padding(4);
            this.txtAuthor.Name = "txtAuthor";
            this.txtAuthor.Size = new System.Drawing.Size(188, 28);
            this.txtAuthor.TabIndex = 14;
            // 
            // txtBookName
            // 
            this.txtBookName.Location = new System.Drawing.Point(94, 82);
            this.txtBookName.Margin = new System.Windows.Forms.Padding(4);
            this.txtBookName.Name = "txtBookName";
            this.txtBookName.Size = new System.Drawing.Size(188, 28);
            this.txtBookName.TabIndex = 13;
            // 
            // lblBookBarcode
            // 
            this.lblBookBarcode.AutoSize = true;
            this.lblBookBarcode.Location = new System.Drawing.Point(9, 33);
            this.lblBookBarcode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBookBarcode.Name = "lblBookBarcode";
            this.lblBookBarcode.Size = new System.Drawing.Size(98, 18);
            this.lblBookBarcode.TabIndex = 13;
            this.lblBookBarcode.Text = "图书条码：";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(9, 303);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(62, 18);
            this.lblPrice.TabIndex = 8;
            this.lblPrice.Text = "价格：";
            // 
            // lblBookName
            // 
            this.lblBookName.AutoSize = true;
            this.lblBookName.Location = new System.Drawing.Point(9, 87);
            this.lblBookName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBookName.Name = "lblBookName";
            this.lblBookName.Size = new System.Drawing.Size(98, 18);
            this.lblBookName.TabIndex = 12;
            this.lblBookName.Text = "图书名称：";
            // 
            // lblNowNums
            // 
            this.lblNowNums.AutoSize = true;
            this.lblNowNums.Location = new System.Drawing.Point(9, 249);
            this.lblNowNums.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNowNums.Name = "lblNowNums";
            this.lblNowNums.Size = new System.Drawing.Size(98, 18);
            this.lblNowNums.TabIndex = 9;
            this.lblNowNums.Text = "现存数量：";
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(9, 141);
            this.lblAuthor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(62, 18);
            this.lblAuthor.TabIndex = 11;
            this.lblAuthor.Text = "作者：";
            // 
            // lblTotalNums
            // 
            this.lblTotalNums.AutoSize = true;
            this.lblTotalNums.Location = new System.Drawing.Point(9, 195);
            this.lblTotalNums.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalNums.Name = "lblTotalNums";
            this.lblTotalNums.Size = new System.Drawing.Size(98, 18);
            this.lblTotalNums.TabIndex = 10;
            this.lblTotalNums.Text = "总藏书量：";
            // 
            // gbLoanInfo
            // 
            this.gbLoanInfo.Controls.Add(this.dgLoanInfo);
            this.gbLoanInfo.Location = new System.Drawing.Point(6, 378);
            this.gbLoanInfo.Margin = new System.Windows.Forms.Padding(4);
            this.gbLoanInfo.Name = "gbLoanInfo";
            this.gbLoanInfo.Padding = new System.Windows.Forms.Padding(4);
            this.gbLoanInfo.Size = new System.Drawing.Size(624, 193);
            this.gbLoanInfo.TabIndex = 2;
            this.gbLoanInfo.TabStop = false;
            this.gbLoanInfo.Text = "当前借阅者的已借书情况";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(359, 591);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(104, 34);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "关闭(&C)";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnLoan
            // 
            this.btnLoan.Location = new System.Drawing.Point(184, 591);
            this.btnLoan.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoan.Name = "btnLoan";
            this.btnLoan.Size = new System.Drawing.Size(104, 34);
            this.btnLoan.TabIndex = 6;
            this.btnLoan.Text = "借出(&L)";
            this.btnLoan.UseVisualStyleBackColor = true;
            this.btnLoan.Click += new System.EventHandler(this.btnLoan_Click);
            // 
            // frmBookLoanManage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 645);
            this.Controls.Add(this.btnLoan);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.gbLoanInfo);
            this.Controls.Add(this.gbBookInfo);
            this.Controls.Add(this.gbBorrowerInfo);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBookLoanManage";
            this.Text = "图书借出";
            this.Load += new System.EventHandler(this.frmBookLoanManage_Load);
            this.gbBorrowerInfo.ResumeLayout(false);
            this.gbBorrowerInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgLoanInfo)).EndInit();
            this.gbBookInfo.ResumeLayout(false);
            this.gbBookInfo.PerformLayout();
            this.gbLoanInfo.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbBorrowerInfo;
        private System.Windows.Forms.DataGridView dgLoanInfo;
        private System.Windows.Forms.Label lblBorrowerId;
        private System.Windows.Forms.TextBox txtBorrowerId;
        private System.Windows.Forms.Button btnSelectBorrowerId;
        private System.Windows.Forms.Label lblForegift;
        private System.Windows.Forms.Label lblLoan;
        private System.Windows.Forms.Label lblPermitNums;
        private System.Windows.Forms.Label lblCardState;
        private System.Windows.Forms.Label lblBorrowerName;
        private System.Windows.Forms.GroupBox gbBookInfo;
        private System.Windows.Forms.Label lblBookBarcode;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblBookName;
        private System.Windows.Forms.Label lblNowNums;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblTotalNums;
        private System.Windows.Forms.GroupBox gbLoanInfo;
        private System.Windows.Forms.TextBox txtForegift;
        private System.Windows.Forms.TextBox txtLoanNums;
        private System.Windows.Forms.TextBox txtPermitNums;
        private System.Windows.Forms.TextBox txtCardState;
        private System.Windows.Forms.TextBox txtBorrowerName;
        private System.Windows.Forms.TextBox txtBookBarcode;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtNowNums;
        private System.Windows.Forms.TextBox txtTotalNums;
        private System.Windows.Forms.TextBox txtAuthor;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnLoan;
        private System.Windows.Forms.Button btnSelectBookBarcode;
    }
}