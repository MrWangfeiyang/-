﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookUI
{
    public partial class frmSelectLoanBook : Form
    {
       
        BookApp.loanClass objLoan = new BookApp.loanClass();
        DataTable dt = new DataTable();
        Point startLocation;

        public frmSelectLoanBook(Point winLocation)
        {
            InitializeComponent();
            startLocation = winLocation;
        }
        public string getLoanBookId()
        {
            return dt.Rows[dataGridView1.CurrentRow.Index]["图书条码"].ToString();
        }

        private void frmSelectLoanBook_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Location = new Point(startLocation.X, startLocation.Y);
            dt = objLoan.getLoanInfo("");
            dataGridView1.DataSource = dt.DefaultView;
        }

        

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Yes;
        }

        
    }
}
