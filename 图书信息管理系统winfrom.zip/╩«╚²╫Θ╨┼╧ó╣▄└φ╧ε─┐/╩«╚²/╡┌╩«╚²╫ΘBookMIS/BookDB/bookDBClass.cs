﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace BookDB
{

    public class bookDBClass
    {
        SqlConnection conn;//定义为窗体级局部变量
        private void openConnection()
        {
            //数据库连接字符串
            string strConn = "Server=(local);Database=第十三组BookDB;" +
                "Integrated Security=SSPI;Persist Security Info=False";
            conn = new SqlConnection(strConn);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        private void closeConnection()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }
        public DataTable getDataBySQL(string strComm)
        {
            SqlDataAdapter adapterSql;
            DataSet ds = new DataSet();
            try
            {
                openConnection();
                adapterSql = new SqlDataAdapter(strComm, conn);
                adapterSql.Fill(ds, "table01");
                closeConnection();
                //返回生成的数据表
                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                //异常报告
                MessageBox.Show("创建数据表发生异常！ 异常原因:"
                    + ex.Message, "错误提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }
        public bool updateDataTable(string strComm)
        {
            try
            {
                SqlCommand comm;
                openConnection();
                comm = new SqlCommand(strComm, conn);
                comm.ExecuteNonQuery();
                closeConnection();
                //更新成功
                return true;
            }
            catch (Exception ex)
            {
                //更新失败,返回失败原因
                MessageBox.Show("更新数据失败!" + ex.Message, "提示信息",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        public int getNums(string commStr)
        {
            int nums = 0;
            SqlCommand comm = default(SqlCommand);
            openConnection();
            comm = new SqlCommand(commStr, conn);
            nums = Convert.ToInt32(comm.ExecuteScalar());
            closeConnection();
            return nums;
        }


    }
}

