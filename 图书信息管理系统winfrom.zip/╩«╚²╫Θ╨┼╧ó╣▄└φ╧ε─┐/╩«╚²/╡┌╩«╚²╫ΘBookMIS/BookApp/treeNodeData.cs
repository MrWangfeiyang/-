﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookApp
{
    public class treeNodeData
    {
        public string BookTypeCode;
        public string BookTypeName;
        public string BookTypeExplain;
        public string ItemIndex;
        public string ParentIndex;
        public treeNodeData(string strBookTypeCode, string strBookTypeName,
            string strBookTypeExplain, string strItemIndex, string strParentIndex)
        {
            BookTypeCode = strBookTypeCode;
            BookTypeName = strBookTypeName;
            BookTypeExplain = strBookTypeExplain;
            ItemIndex = strItemIndex;
            ParentIndex = strParentIndex;
        }
    }
}

    
