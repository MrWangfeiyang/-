﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace BookApp
{
   public class publisherClass
    {
        BookDB.bookDBClass objBookDB = new BookDB.bookDBClass();

        public DataTable getPublisherInfo()
        {
            string strComm;
            strComm = "Select 出版社编号,出版社名称,ISBN,出版社简称,出版社地址 "
                +" From 出版社";
            return objBookDB.getDataBySQL(strComm);
        }

        public bool publisherInfoAdd(string publisherName, string ISBN,
            string shortName, string publisherAddress)
        {
            string strInsertComm;
            strInsertComm = "Inser Into 出版社(出版社名称,ISBN,出版社简称,出版社地址)"
                + "Values('" + publisherName + "','" + ISBN + "','"
                + shortName + "','" + publisherAddress + "')";
            return objBookDB.updateDataTable(strInsertComm);
        }

        public bool publisherInfoEdit(string publisherID, string publisherName,
            string ISBN, string shortName, string publisherAddress)
        {
            string strEditComm = null;
            strEditComm = "Update 出版社 Set 出版社名称='" + publisherName
                + "'," + "ISBN='" + ISBN + "'," + " 出版社简称='"
                + shortName + "'," + " 出版社地址='"
                + publisherAddress + "'" + " Where 出版社编号='"
                    + publisherID + "'";
            return objBookDB.updateDataTable(strEditComm);
        }

        public bool publisherInfoDelete(string publisherID)
        {
            string strSql;
            strSql = "Delete From 出版社 Where 出版社编号='" + publisherID + "'";
            return objBookDB.updateDataTable(strSql);
        }
    }
}
