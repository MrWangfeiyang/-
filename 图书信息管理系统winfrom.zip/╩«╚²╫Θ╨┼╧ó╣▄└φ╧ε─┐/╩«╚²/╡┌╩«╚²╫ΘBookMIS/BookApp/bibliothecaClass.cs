﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace BookApp
{
   public class bibliothecaClass
    {
        BookDB.bookDBClass objBookDb = new BookDB.bookDBClass();
        public DataTable getBibliothecaDataAll()
        {
            string strSql = null;
            strSql = "select 书目编号 ,图书名称 ,作者 ,出版社名称 ,"
                + "ISBN ,出版日期 ,图书页数 ,价格 ,图书类型名称 ,"
                + "总藏书数量 ,现存数量 ,馆藏地点 ,简介 from bibliothecaView";
            return objBookDb.getDataBySQL(strSql);
        }
        public DataTable getBibliothecaInfoByName(string bookName)
        {
            //根据查询条件检索数据表
            string strSql = null;
            strSql = "Select 书目编号 ,图书名称 ,作者 ,出版社名称 ,"
                + "ISBN ,出版日期 ,图书页数 ,价格 ,图书类型名称 ,"
                + "总藏书数量 ,现存数量 ,馆藏地点 ,简介 "
                + "From bibliothecaView Where 图书名称 Like '%"
                + bookName + "%'";
            return objBookDb.getDataBySQL(strSql);
        }
        public DataTable getBibliothecaInfoById(string bibliothecaId)
        {
            //根据查询条件检索数据表
            string strSql = null;
            strSql = "Select 书目编号 ,图书名称 ,作者 ,出版社名称 ,"
                + "ISBN ,出版日期 ,图书页数 ,价格 ,图书类型名称 ,"
                + "总藏书数量 ,现存数量 ,馆藏地点 ,简介 "
                + "From bibliothecaView where 书目编号 Like '"
                + bibliothecaId + "%'";
            return objBookDb.getDataBySQL(strSql);
        }
        public DataTable getBibliothecaData(string bibliothecaNo)
        {
            return objBookDb.getDataBySQL("Select * From bibliothecaView"
                + " Where 书目编号='" + bibliothecaNo + "'");
        }
        public DataTable getBookTypeNameAll()
        {
            return objBookDb.getDataBySQL("Select 图书类型名称 From 图书类型");
        }
        public DataTable getBookTypeId(string bookType)
        {
            return objBookDb.getDataBySQL("Select 图书类型代码 From 图书类型"
                + " Where 图书类型名称='" + bookType + "'");
        }

        public DataTable getPublisherName()
        {
            return objBookDb.getDataBySQL("Select 出版社名称 From 出版社");
        }
        public DataTable getPublisherISBN(string publisher)
        {
            return objBookDb.getDataBySQL("Select ISBN From 出版社 "
              + " Where 出版社名称='" + publisher + "'");
        }
        public DataTable getDepositary()
        {
            return objBookDb.getDataBySQL("Select 馆藏地点编号 From 馆藏地点");
        }

        public bool bibliothecaAdd(string bibliothecaID, string bibliothecaName,
            string author, string publisherISBN, string ISBN, string publishDate,
            int pages, float price, string bookType, int nowNums,
            string place, string synopsis, int inNums)
        {
            string strInsertComm = null;
            strInsertComm = "Insert Into 书目信息(书目编号 ,图书名称 ,作者 ,"
                + "出版社 ,ISBN ,出版日期 ,图书页数 ,价格 ,图书类型 ,"
                + "现存数量 ,馆藏地点 , 简介 ,待入库数量) Values('"
                + bibliothecaID + "','" + bibliothecaName
                + "','" + author + "','" + publisherISBN
                + "','" + ISBN + "','" + publishDate
                + "','" + pages + "','" + price
                + "','" + bookType + "','"
                + nowNums + "','" + place
                + "','" + synopsis + "','" + inNums + "')";
            return objBookDb.updateDataTable(strInsertComm);
        }

         public bool bibliothecaEditAll(string bibliothecaID,string bibliothecaName,
            string author,string publisher,string ISBN,string publishDate,
             int pages,float price,string bookType,int totalNums,
            int nowNums,string place,string synopsis,string keyField)
        {
            string strEditComm = null;
            strEditComm = "Update 书目信息 Set 书目编号='" + bibliothecaID + "',"
                + " 图书名称='" + bibliothecaName + "'," + " 作者='" + author + "',"
                + " 出版社='" + publisher + "'," + " ISBN='" + ISBN + "',"
                + " 出版日期='" + publishDate + "'," + " 图书页数='" + pages + "',"
                + " 价格='" + price + "'," + " 图书类型='" + bookType + "',"
                + " 总藏书数量='" + totalNums + "'," + " 现存数量='" + nowNums + "',"
                + " 馆藏地点='" + place + "'," + " 简介='" + synopsis + "'"
                + " Where  书目信息='" + keyField + "'";
            return objBookDb.updateDataTable(strEditComm);
        }

        public bool bibliothecaEditPart(string bibliothecaID,string bibliothecaName,
            string author,string publisher,string ISBN,
            string publishDate,int pages,float price,
            string bookType,int totalNums,
            int nowNums,string place,string synopsis)
        {
            string strEditComm = null;
            strEditComm = "Update 书目信息 Set "+" 图书名称='" + bibliothecaName + "',"
               + " 作者='" + author + "',"+ " 出版社='" + publisher + "',"
               + " ISBN='" + ISBN + "',"+ " 出版日期='" + publishDate + "',"
               + " 图书页数='" + pages + "',"+ " 价格='" + price + "',"
               + " 图书类型='" + bookType + "',"+" 总藏书数量='" + totalNums + "',"
               + " 现存数量='" + nowNums + "',"+ " 馆藏地点='" + place + "'," 
               + " 简介='" + synopsis + "'"+ " Where  书目编号='" 
               + bibliothecaID + "'";
            return objBookDb.updateDataTable(strEditComm);
        }

        public bool bibliothecaDelete(string bibliothecaID)
        {
            if (objBookDb.updateDataTable("Delete From 书目信息 Where 书目编号='"
                + bibliothecaID + "'") == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
