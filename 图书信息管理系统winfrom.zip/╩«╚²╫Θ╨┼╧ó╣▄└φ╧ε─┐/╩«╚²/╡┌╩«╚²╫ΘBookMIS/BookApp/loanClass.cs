﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;

namespace BookApp
{
   public class loanClass
    {
      BookDB.bookDBClass objBookDb = new BookDB.bookDBClass();

        public DataTable getBorrowerInfo(string borrowerId)
        {
            string strSql = null;
            if(string.IsNullOrEmpty(borrowerId)) {
                strSql  = "Select 借阅者编号,姓名,借阅者类型,借书证状态,"
                +"最大借书数量,最长借书期限,押金剩余,借书证状态 "
                +"From borrowerView Where 借书证状态='有效'";
        }
        else{
            strSql = "Select 借阅者编号,姓名,借阅者类型,借书证状态,"
                +"最大借书数量,最长借书期限,押金剩余,借书证状态 "
                + "From borrowerView Where 借阅者编号='" + borrowerId + "'";
        }
        return objBookDb.getDataBySQL(strSql);
  }
        public DataTable getBookInfo(string bookBarcode)
        {
            string strSql = null;
            if(string.IsNullOrEmpty(bookBarcode)) {
                strSql  = "Select 图书条码,书目编号,图书名称,价格,出版社名称,作者,"
                +"总藏书数量,现存数量 From bookView Where 图书状态='在藏'";
        }
        else{
            strSql = "Select 图书条码,书目编号,图书名称,价格,出版社名称,作者,"
                +"总藏书数量,现存数量 From bookView  "  
                +"Where 图书条码='"+bookBarcode +"'";
        }
        return objBookDb.getDataBySQL(strSql);
     }

        public object getLoanBookNums(string borrowerId)
        {
            string commStr = null;
            commStr = "Select count(*)From 借阅信息 Where 借阅者编号='" +
                borrowerId + "'";
            return objBookDb.getNums(commStr);
       }
        public DataTable getLoanInfo(string borrowerId)
        {
            if (string.IsNullOrEmpty(borrowerId))
            {
                return objBookDb.getDataBySQL("Select 借阅者编号,姓名,"
                    + "图书条码,图书名称,借出日期,应还日期,续借次数,图书借阅员 "
                    + "From loanView");
            }
            else
            {
                return objBookDb.getDataBySQL("Select 借阅者编号,姓名,"
                    + "图书条码,图书名称,借出日期,应还日期,续借次数,图书借阅员 "
                     + "From loanView Where 借阅者编号='"
                     + borrowerId + "' Order by 借阅编号");
            }
        }
        public DataTable getOverdueInfo(string borrowerId)
        {
            string strSql = null;
            strSql = "Select 借阅者编号,姓名,图书条码,图书名称,"
                + "价格,借出日期,应还日期,续借次数,"
                 + " 图书借阅员,书目编号 From loanView"
                  +"  Where 应还日期 <'"+DateTime.Today.ToShortDateString()
                   +"'And  借阅者编号='" + borrowerId + "'";
            return objBookDb.getDataBySQL(strSql);
        }
        public bool isOverdue(string borrowerId)
        {
            DataTable dt = new DataTable();
            dt = getOverdueInfo(borrowerId);
            if (dt.Rows.Count != 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public bool loanAdd(string borrowerId, string bookBarcode,
            System.DateTime loanDate, System.DateTime returnDate,
            int loanNums, string loanerName)
        {
            //增加书目记录
            string strInsertComm = null;
            strInsertComm = "Insert Into 借阅信息(借阅者编号,图书条码,借出日期,"
               + " 应还日期,续借次数,图书借阅员)Values('"
               + borrowerId + "','" + bookBarcode + "','" + loanDate
               + "','" + returnDate + "','" + loanNums + "','"
               + loanerName + "')";
            return objBookDb.updateDataTable(strInsertComm);
        }
        public object bookNowNumReduce(string bibliothecaId)
        {
            //修改借出图书的馆藏书量
            string strEditComm = null;
            strEditComm = "update 书目信息 set 现存数量=现存数量-1"
                + "Where 书目编号='" + bibliothecaId + "'";
            return objBookDb.updateDataTable(strEditComm);
        }
        public bool setBookState(string bookBarcode,string bookState)
        {
            string strSql = null;
            strSql = "update 图书信息 set 图书状态='" + bookState
                +"' Where 图书条码='" +bookBarcode + "'";
            return objBookDb.updateDataTable(strSql);
        }
	}
}