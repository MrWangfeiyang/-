﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;


namespace BookApp
{
    public class bookUserClass
    {
        BookDB.bookDBClass objBookDB = new BookDB.bookDBClass();

        public DataTable getUserName()
        {
            string strComm;
            strComm = "Select 用户名 From 用户信息";
            return objBookDB.getDataBySQL(strComm);
        }

        public DataTable getUserInfo(string userName, string password)
        {
            string strComm;
            strComm = "Select 用户编号,用户名,密码 From 用户信息 Where 用户名='" + userName + "' And 密码='" + password + "'";
            return objBookDB.getDataBySQL(strComm);
        }

        public DataTable getUserInfo(string userName)
        {
            string strComm;
            strComm = "Select 用户编号,用户名,密码 From 用户信息 Where 用户名='" + userName + " '";
            return objBookDB.getDataBySQL(strComm);
        }






        public DataTable getUserInfoAll()
        {
            string strComm;
            strComm = "Select 用户编号,用户名,密码,ID From 用户信息";
            return objBookDB.getDataBySQL(strComm);
        }
        public DataTable getUserInfoByListNum(string listNum)
        {
            string strComm;
            strComm = "Select 用户编号,用户名,密码 From 用户信息 Where 用户编号='" + listNum + "'";
            return objBookDB.getDataBySQL(strComm);
        }
        public bool userAdd(string userListNum, string userName, string userPassword)
        {
            string strInsertComm;
            strInsertComm = "Insert Into 用户信息(用户编号,用户名,密码)Values('" + userListNum + "','" + userName + "','" + userPassword + "')";
            return objBookDB.updateDataTable(strInsertComm);
        }
        public bool userInfoEdit(string userListNum, string userName, string userPassword, int id)
        {
            string strEditComm;
            strEditComm = "Update 用户信息 Set 用户编号='" + userListNum + "',用户名='" + userName + "',密码='" + userPassword + "'Where ID=" + id;
            return objBookDB.updateDataTable(strEditComm);
        }
        public void userDataDelete(string listNum)
        {
            string strSql;
            strSql = "Delete From 用户信息 Where 用户编号='" + listNum + "'";
            objBookDB.updateDataTable(strSql);
        }
        public bool editPassword(string userName, string password)
        {
            string strComm;
            strComm = "Update UserLogin Set UserPassword='" + password + "'Where Name='" + userName + "'";
            return objBookDB.updateDataTable(strComm);
        }


    }
}