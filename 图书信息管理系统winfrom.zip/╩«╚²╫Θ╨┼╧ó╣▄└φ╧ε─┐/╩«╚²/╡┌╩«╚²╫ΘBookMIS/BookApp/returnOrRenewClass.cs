﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace BookApp
{
    public class returnOrRenewClass
    {
         BookDB.bookDBClass objBookDb = new BookDB.bookDBClass();
        public DataTable getLoanInfoByBarcode(string barcode)
        {
            return objBookDb.getDataBySQL("Select 借阅编号 ,借阅者编号 姓名,"
                    + "图书条码,图书名称,借出日期,应还日期,续借次数,图书借阅员 "
                     + "From loanView Where 图书条码='"
                     + barcode + "' Order by 借阅编号");
        }
        public bool loanRenew(int maxDay, string borrowerId, string bookBarcode)
        {
            string strSql = null;
            strSql = "Update 借阅信息 Set 借出日期='"
                + DateTime.Today.ToShortDateString()
                + "',应还日期='"
                + DateTime.Now.AddDays(maxDay).Date.ToShortDateString()
                + "',续借次数=续借次数+1  Where 借阅者编号='"
                + borrowerId + "'And 图书条码='" + bookBarcode + "'";
            return objBookDb.updateDataTable(strSql);
        }
        public bool loanDelete(string borrowerId, string bookCode)
        {
            string strSql = null;
            strSql = "Delete From 借阅信息  Where 借阅者编号='"
                + borrowerId + "'And 图书条码='" + bookCode + "'";
            if (objBookDb.updateDataTable(strSql) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public object bookNowNumAdd(string bibliothecaId)
        {
            string strEditComm = null;
            strEditComm = "Updata 书目信息 Set 现存数量=现存数量+1" +
                " Where 书目编号='" + bibliothecaId + "'";
            return objBookDb.updateDataTable(strEditComm);
        }
    }

}
