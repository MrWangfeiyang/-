﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BookApp
{
   public class bookTypeClass
    {
        BookDB.bookDBClass objBookDB = new BookDB.bookDBClass();

        public DataTable getBookType()
        {
            string strComm;
            strComm = "Select 图书类型代码 ,图书类型名称 ,图书类型说明 ,"
                + "类型层次编号 ,类型父项编号 "
                + " From 图书类型 Order By 图书类型代码";
            return objBookDB.getDataBySQL(strComm);
        }
        public void initTrvTree(TreeNodeCollection treeNodes,
            string strParentIndex,DataView dvList)
        {
            try
            {
                TreeNode tempNode;
                DataView dvList1;
                string currentNum;
                dvList1 = dvList;
                //选出数据源中父部门编号为strParentIndex的数据行
                DataRow[] dataRows = dvList.Table.Select("类型父项编号 ='"+ strParentIndex + "'");
                //循环添加TreeNode
                foreach(DataRow dr in dataRows)
                {
                    tempNode = new TreeNode();
                    tempNode.Text = dr["图书类型代码"].ToString() +"-"
                        + dr["图书类型名称"].ToString();
                    //用TreeNode的Tag属性保存与此节点相关的数据
                    tempNode.Tag =new treeNodeData(dr["图书类型代码"].ToString(),
                        dr["图书类型名称"].ToString(),
                        dr["图书类型说明"].ToString(),
                        dr["类型层次编号"].ToString(),
                          dr["类型父项编号"].ToString());
                    currentNum = dr["类型层次编号"].ToString();
                    treeNodes.Add(tempNode);
                    //递归调用,treeNodes.Count-1].Nodes;
                    TreeNodeCollection temp_nodes=treeNodes[treeNodes.Count-1].Nodes;
                    initTrvTree(temp_nodes,currentNum,dvList1);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("初始化 TreeView 失败");
            }
        }
        public bool saveForAdd(string bookTypeCode, string bookTypeName, string bookTypeExplain, string currentCode, string parentCode)
        {
            string strSql = null;
            try
            {
                strSql = "Insert Into 图书类型(图书类型代码 ,图书类型名称,";
                strSql += "图书类型说明 ,类型层次编号 ,类型父项编号)";
                strSql += "Values ('";
                strSql += bookTypeCode + "','";
                strSql += bookTypeName + "','";
                strSql += bookTypeExplain + "','";
                strSql += currentCode + "','";
                strSql += parentCode + "')";
                return objBookDB.updateDataTable(strSql);
            }
            catch
            {
                MessageBox.Show("新增数据失败! ", "提示信息",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }
        public bool saveForEdit(string bookTypeCode, string bookTypeName,
            string bookTypeExplain, string CurrentCode, string parentCode)
        {
            string strSql = null;
            try
            {
                strSql = "Update 图书类型 Set";
                strSql += "图书类型名称='" + bookTypeName + "',";
                strSql += "图书类型说明='" + bookTypeExplain + "',";
                strSql += "类型层次编号='" + CurrentCode + "',";
                strSql += "类型父项编号='" + parentCode + "'";
                strSql += " Where 图书类型代码='" + bookTypeCode + "'";
                return objBookDB.updateDataTable(strSql);
            }
            catch
            {
                MessageBox.Show("修改数据失败!", "提示信息");
                return false;
            }
        }
        public void deleteData(string bookTypeCode)
        {
            string strSql;
            strSql = "Delete From 图书类型 Where 图书类型代码='" + bookTypeCode +"'";
            objBookDB.updateDataTable(strSql);
        }
    }
}

